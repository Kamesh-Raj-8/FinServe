package com.smelend.smelendbackend.service.kyc;

import com.smelend.smelendbackend.dto.kyc.CreateKycRequest;
import com.smelend.smelendbackend.dto.kyc.KycActionRequest;
import com.smelend.smelendbackend.dto.kyc.KycResponse;
import com.smelend.smelendbackend.entity.AppUser;
import com.smelend.smelendbackend.entity.KycRecord;
import com.smelend.smelendbackend.entity.Promoter;
import com.smelend.smelendbackend.entity.Sme;
import com.smelend.smelendbackend.entity.enums.ApplicationStatus;
import com.smelend.smelendbackend.entity.enums.AuditAction;
import com.smelend.smelendbackend.entity.enums.KycStatus;
import com.smelend.smelendbackend.exception.ApiException;
import com.smelend.smelendbackend.repository.AppUserRepository;
import com.smelend.smelendbackend.repository.KycRecordRepository;
import com.smelend.smelendbackend.repository.LoanApplicationRepository;
import com.smelend.smelendbackend.repository.PromoterRepository;
import com.smelend.smelendbackend.repository.SmeRepository;
import com.smelend.smelendbackend.service.common.CurrentUserService;
import com.smelend.smelendbackend.service.compliance.AuditLogService;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class KycService {

    private final KycRecordRepository kycRepo;
    private final SmeRepository smeRepo;
    private final PromoterRepository promoterRepo;
    private final AppUserRepository userRepo;
    private final LoanApplicationRepository appRepo;
    private final CurrentUserService currentUserService;
    private final AuditLogService auditLogService;

    public KycService(KycRecordRepository kycRepo,
                      SmeRepository smeRepo,
                      PromoterRepository promoterRepo,
                      AppUserRepository userRepo,
                      LoanApplicationRepository appRepo,
                      CurrentUserService currentUserService,
                      AuditLogService auditLogService) {
        this.kycRepo = kycRepo;
        this.smeRepo = smeRepo;
        this.promoterRepo = promoterRepo;
        this.userRepo = userRepo;
        this.appRepo = appRepo;
        this.currentUserService = currentUserService;
        this.auditLogService = auditLogService;
    }

    /** Applicant/Agent creates a KYC record (starts as PENDING). */
    public KycResponse create(CreateKycRequest req) {
        AppUser me = currentUserService.getCurrentUser();
        requireApplicantAgentOrAdmin(me);

        Sme sme = smeRepo.findById(req.getSmeId())
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "SME not found"));

        Promoter promoter = null;
        if (req.getPromoterId() != null) {
            promoter = promoterRepo.findById(req.getPromoterId())
                    .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Promoter not found"));
        }

        AppUser applicant = null;
        if (req.getApplicantId() != null) {
            applicant = userRepo.findById(req.getApplicantId())
                    .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Applicant user not found"));
        }

        KycRecord saved = kycRepo.save(KycRecord.builder()
                .sme(sme)
                .promoter(promoter)
                .applicant(applicant)
                .verificationStatus(KycStatus.PENDING)
                .notes(null)
                .verifiedBy(null)
                .verifiedDate(null)
                .build());

        auditLogService.log(me, AuditAction.KYC_CREATED, "KYC", saved.getKycId(),
                "KYC created for SME " + sme.getSmeId());

        markDraftAppsAsKycPending(sme.getSmeId());

        return toDto(saved);
    }

    /** Agent/Admin views ALL KYC records in the system. */
    public List<KycResponse> listAll() {
        AppUser me = currentUserService.getCurrentUser();
        requireAgentOrAdmin(me);
        return kycRepo.findAll().stream().map(this::toDto).toList();
    }

    /** Agent/Admin views all PENDING KYC records. */
    public List<KycResponse> listAllPending() {
        AppUser me = currentUserService.getCurrentUser();
        requireAgentOrAdmin(me);
        return kycRepo.findByVerificationStatus(KycStatus.PENDING)
                .stream().map(this::toDto).toList();
    }

    /** Applicant/Agent/Admin views KYC records for a specific SME. */
    public List<KycResponse> listBySme(Long smeId) {
        AppUser me = currentUserService.getCurrentUser();
        requireApplicantAgentOrAdmin(me);

        Sme sme = smeRepo.findById(smeId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "SME not found"));

        return kycRepo.findBySme_SmeId(sme.getSmeId())
                .stream().map(this::toDto).toList();
    }

    /** Fetch a single KYC record by ID. */
    public KycResponse getById(Long kycId) {
        AppUser me = currentUserService.getCurrentUser();
        requireApplicantAgentOrAdmin(me);
        KycRecord kyc = kycRepo.findById(kycId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "KYC record not found"));
        return toDto(kyc);
    }

    /** Only AGENT/ADMIN verifies KYC. */
    public KycResponse verify(Long kycId, KycActionRequest req) {
        AppUser me = currentUserService.getCurrentUser();
        requireAgentOrAdmin(me);

        KycRecord kyc = kycRepo.findById(kycId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "KYC record not found"));

        kyc.setVerificationStatus(KycStatus.VERIFIED);
        kyc.setVerifiedBy(me);
        kyc.setVerifiedDate(LocalDate.now());
        kyc.setNotes(req != null ? req.getNotes() : null);

        KycRecord saved = kycRepo.save(kyc);

        auditLogService.log(me, AuditAction.KYC_VERIFIED, "KYC", saved.getKycId(), "KYC verified");

        markAppsReadyToSubmit(saved.getSme().getSmeId());

        return toDto(saved);
    }

    /** Only AGENT/ADMIN rejects KYC. */
    public KycResponse reject(Long kycId, KycActionRequest req) {
        AppUser me = currentUserService.getCurrentUser();
        requireAgentOrAdmin(me);

        KycRecord kyc = kycRepo.findById(kycId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "KYC record not found"));

        kyc.setVerificationStatus(KycStatus.REJECTED);
        kyc.setVerifiedBy(me);
        kyc.setVerifiedDate(LocalDate.now());
        kyc.setNotes(req != null ? req.getNotes() : null);

        KycRecord saved = kycRepo.save(kyc);

        auditLogService.log(me, AuditAction.KYC_REJECTED, "KYC", saved.getKycId(), "KYC rejected");

        return toDto(saved);
    }

    // ── Helpers ────────────────────────────────────────────────────────

    private void requireApplicantAgentOrAdmin(AppUser me) {
        String role = me.getRole().getRoleName().name();
        if (!(role.equals("APPLICANT") || role.equals("AGENT") || role.equals("ADMIN")
                || role.equals("UNDERWRITER"))) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Access denied for role: " + role);
        }
    }

    private void requireAgentOrAdmin(AppUser me) {
        String role = me.getRole().getRoleName().name();
        if (!(role.equals("AGENT") || role.equals("ADMIN"))) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Only AGENT/ADMIN can perform this action");
        }
    }

    private void markDraftAppsAsKycPending(Long smeId) {
        appRepo.findAll().stream()
                .filter(a -> a.getSme() != null && a.getSme().getSmeId().equals(smeId))
                .filter(a -> a.getStatus() == ApplicationStatus.DRAFT)
                .forEach(a -> { a.setStatus(ApplicationStatus.KYC_PENDING); appRepo.save(a); });
    }

    private void markAppsReadyToSubmit(Long smeId) {
        // All KYC for this SME must be VERIFIED before marking apps ready
        boolean anyPending = kycRepo.existsBySme_SmeIdAndVerificationStatus(smeId, KycStatus.PENDING);
        if (!anyPending) {
            appRepo.findAll().stream()
                    .filter(a -> a.getSme() != null && a.getSme().getSmeId().equals(smeId))
                    .filter(a -> a.getStatus() == ApplicationStatus.KYC_PENDING
                              || a.getStatus() == ApplicationStatus.DRAFT)
                    .forEach(a -> { a.setStatus(ApplicationStatus.READY_TO_SUBMIT); appRepo.save(a); });
        }
    }

    private KycResponse toDto(KycRecord k) {
        return KycResponse.builder()
                .kycId(k.getKycId())
                .smeId(k.getSme() != null ? k.getSme().getSmeId() : null)
                .smeLegalName(k.getSme() != null ? k.getSme().getLegalName() : null)
                .promoterId(k.getPromoter() != null ? k.getPromoter().getPromoterId() : null)
                .promoterName(k.getPromoter() != null ? k.getPromoter().getPromoterName() : null)
                .applicantId(k.getApplicant() != null ? k.getApplicant().getUserId() : null)
                .applicantEmail(k.getApplicant() != null ? k.getApplicant().getEmail() : null)
                .applicantFullName(k.getApplicant() != null ? k.getApplicant().getFullName() : null)
                .verificationStatus(k.getVerificationStatus())
                .verifiedDate(k.getVerifiedDate())
                .verifiedByUserId(k.getVerifiedBy() != null ? k.getVerifiedBy().getUserId() : null)
                .verifiedByEmail(k.getVerifiedBy() != null ? k.getVerifiedBy().getEmail() : null)
                .notes(k.getNotes())
                .build();
    }
}