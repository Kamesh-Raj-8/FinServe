package com.smelend.smelendbackend.service.application;

import com.smelend.smelendbackend.dto.document.AddDocumentRequest;
import com.smelend.smelendbackend.dto.document.DocumentResponse;
import com.smelend.smelendbackend.entity.AppUser;
import com.smelend.smelendbackend.entity.Document;
import com.smelend.smelendbackend.entity.LoanApplication;
import com.smelend.smelendbackend.entity.enums.DocType;
import com.smelend.smelendbackend.entity.enums.UploadStatus;
import com.smelend.smelendbackend.exception.ApiException;
import com.smelend.smelendbackend.repository.DocumentRepository;
import com.smelend.smelendbackend.repository.LoanApplicationRepository;
import com.smelend.smelendbackend.service.common.CurrentUserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class DocumentService {

    private final DocumentRepository docRepo;
    private final LoanApplicationRepository appRepo;
    private final CurrentUserService currentUserService;

    /** Resolved from application.properties: app.upload.dir */
    private final Path uploadRoot;

    public DocumentService(DocumentRepository docRepo,
                           LoanApplicationRepository appRepo,
                           CurrentUserService currentUserService,
                           @Value("${app.upload.dir:${user.home}/smelend-uploads}") String uploadDir) {
        this.docRepo = docRepo;
        this.appRepo = appRepo;
        this.currentUserService = currentUserService;
        this.uploadRoot = Paths.get(uploadDir).toAbsolutePath().normalize();
    }

    // ── Legacy URI add (URL string) ───────────────────────────────────

    public DocumentResponse add(Long applicationId, AddDocumentRequest req) {
        AppUser me = currentUserService.getCurrentUser();
        LoanApplication app = requireAppAccess(applicationId, me);

        Document saved = docRepo.save(Document.builder()
                .application(app)
                .docType(req.getDocType())
                .fileUri(req.getFileUri())
                .uploadStatus(UploadStatus.UPLOADED)
                .uploadedDate(LocalDateTime.now())
                .build());

        return toDto(saved);
    }

    // ── Multipart PDF / image upload → stored on filesystem ───────────

    public DocumentResponse uploadFile(Long applicationId, MultipartFile file, DocType docType) {
        AppUser me = currentUserService.getCurrentUser();
        requireAppAccess(applicationId, me);

        if (file == null || file.isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Uploaded file is empty");
        }

        String contentType = file.getContentType();
        if (contentType == null
                || (!contentType.equals("application/pdf") && !contentType.startsWith("image/"))) {
            throw new ApiException(HttpStatus.BAD_REQUEST,
                    "Only PDF and image files are accepted. Received: " + contentType);
        }

        LoanApplication app = appRepo.findById(applicationId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Application not found"));

        // Create per-application subdirectory: <uploadRoot>/app-<applicationId>/
        Path appDir = uploadRoot.resolve("app-" + applicationId);
        try {
            Files.createDirectories(appDir);
        } catch (IOException e) {
            throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Could not create upload directory: " + e.getMessage());
        }

        // Build a unique filename to avoid collisions
        String originalName = file.getOriginalFilename() != null
                ? file.getOriginalFilename() : "upload";
        String uniqueName = UUID.randomUUID() + "_" + originalName;
        Path targetPath = appDir.resolve(uniqueName);

        // Write the stream to disk
        try {
            Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Failed to save file to disk: " + e.getMessage());
        }

        // Persist only the metadata + filesystem path
        Document saved = docRepo.save(Document.builder()
                .application(app)
                .docType(docType)
                .fileUri(targetPath.toString())   // absolute OS path
                .fileName(originalName)
                .contentType(contentType)
                .uploadStatus(UploadStatus.UPLOADED)
                .uploadedDate(LocalDateTime.now())
                .build());

        return toDto(saved);
    }

    // ── Download — read bytes from filesystem ─────────────────────────

    /**
     * Returns the raw bytes of the stored file.
     * Caller checks access before invoking.
     */
    public byte[] downloadFile(Long applicationId, Long documentId) {
        AppUser me = currentUserService.getCurrentUser();
        requireReadAccess(applicationId, me);

        Document doc = docRepo.findById(documentId)
                .filter(d -> d.getApplication().getApplicationId().equals(applicationId))
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Document not found"));

        if (doc.getFileUri() == null || doc.getFileUri().isBlank()) {
            throw new ApiException(HttpStatus.UNPROCESSABLE_ENTITY,
                    "This document has no file attached (URL-only entry)");
        }

        // URL-only entries (http://...) cannot be served as bytes from here
        if (doc.getFileUri().startsWith("http://") || doc.getFileUri().startsWith("https://")) {
            throw new ApiException(HttpStatus.UNPROCESSABLE_ENTITY,
                    "This document is an external URL link — access it directly");
        }

        Path filePath = Paths.get(doc.getFileUri());
        if (!Files.exists(filePath)) {
            throw new ApiException(HttpStatus.NOT_FOUND,
                    "File not found on server: " + doc.getFileName());
        }

        try {
            return Files.readAllBytes(filePath);
        } catch (IOException e) {
            throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "Could not read file: " + e.getMessage());
        }
    }

    /** Returns the Document record (for metadata like fileName, contentType). */
    public Document getDocumentMeta(Long applicationId, Long documentId) {
        AppUser me = currentUserService.getCurrentUser();
        requireReadAccess(applicationId, me);

        return docRepo.findById(documentId)
                .filter(d -> d.getApplication().getApplicationId().equals(applicationId))
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Document not found"));
    }

    // ── List ──────────────────────────────────────────────────────────

    public List<DocumentResponse> list(Long applicationId) {
        AppUser me = currentUserService.getCurrentUser();
        requireReadAccess(applicationId, me);
        return docRepo.findByApplication_ApplicationId(applicationId)
                .stream().map(this::toDto).toList();
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private LoanApplication requireAppAccess(Long applicationId, AppUser me) {
        LoanApplication app = appRepo.findById(applicationId)
                .orElseThrow(() -> new ApiException(HttpStatus.NOT_FOUND, "Application not found"));

        String role = me.getRole().getRoleName().name();
        boolean privileged = role.equals("AGENT") || role.equals("ADMIN")
                || role.equals("UNDERWRITER");
        boolean owner = app.getCreatedBy() != null
                && app.getCreatedBy().getUserId().equals(me.getUserId());

        if (!owner && !privileged) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Access denied for this application");
        }
        return app;
    }

    private void requireReadAccess(Long applicationId, AppUser me) {
        requireAppAccess(applicationId, me);
    }

    private DocumentResponse toDto(Document d) {
        // A file-upload entry: fileUri is an OS path (not http://...)
        boolean isFileUpload = d.getFileUri() != null
                && !d.getFileUri().startsWith("http://")
                && !d.getFileUri().startsWith("https://")
                && d.getFileName() != null;

        String downloadUrl = isFileUpload
                ? "/applications/" + d.getApplication().getApplicationId()
                  + "/documents/" + d.getDocumentId() + "/download"
                : null;

        // For display: show only the original filename, not the full OS path
        String displayUri = isFileUpload ? null : d.getFileUri();

        return DocumentResponse.builder()
                .documentId(d.getDocumentId())
                .applicationId(d.getApplication() != null ? d.getApplication().getApplicationId() : null)
                .docType(d.getDocType())
                .fileUri(displayUri)
                .fileName(d.getFileName())
                .contentType(d.getContentType())
                .downloadUrl(downloadUrl)
                .uploadStatus(d.getUploadStatus())
                .uploadedDate(d.getUploadedDate())
                .build();
    }
}
