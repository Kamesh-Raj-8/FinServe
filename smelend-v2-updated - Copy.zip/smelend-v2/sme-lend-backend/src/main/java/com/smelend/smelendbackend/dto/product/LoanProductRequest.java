package com.smelend.smelendbackend.dto.product;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter @Setter
public class LoanProductRequest {

    @NotBlank
    private String productName;

    @NotNull @DecimalMin(value = "0.0", inclusive = false)
    private BigDecimal minAmount;

    @NotNull @DecimalMin(value = "0.0", inclusive = false)
    private BigDecimal maxAmount;

    @NotNull @Min(1)
    private Integer minTenorMonths;

    @NotNull @Min(1)
    private Integer maxTenorMonths;

    @NotNull @DecimalMin(value = "0.0", inclusive = false)
    private BigDecimal baseInterestRate;
}