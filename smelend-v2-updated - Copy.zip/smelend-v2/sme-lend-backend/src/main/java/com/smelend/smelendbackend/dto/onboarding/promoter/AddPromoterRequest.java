package com.smelend.smelendbackend.dto.onboarding.promoter;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter @Setter
public class AddPromoterRequest {

    @NotBlank
    private String promoterName;

    @NotBlank
    private String mobile;

    @NotNull
    @DecimalMin(value = "0.0", inclusive = false)
    @DecimalMax(value = "100.0", inclusive = true)
    private BigDecimal ownershipPct;
}