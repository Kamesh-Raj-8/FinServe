package com.smelend.smelendbackend.controller.underwriting;

import com.smelend.smelendbackend.dto.ApiResponse;
import com.smelend.smelendbackend.dto.application.ApplicationResponse;
import com.smelend.smelendbackend.dto.document.DocumentResponse;
import com.smelend.smelendbackend.dto.kyc.KycResponse;
import com.smelend.smelendbackend.dto.onboarding.promoter.PromoterResponse;
import com.smelend.smelendbackend.dto.onboarding.sme.SmeResponse;
import com.smelend.smelendbackend.dto.underwriting.UwDecisionRequest;
import com.smelend.smelendbackend.dto.underwriting.UwReviewResponse;
import com.smelend.smelendbackend.service.application.ApplicationService;
import com.smelend.smelendbackend.service.application.DocumentService;
import com.smelend.smelendbackend.service.kyc.KycService;
import com.smelend.smelendbackend.service.onboarding.PromoterService;
import com.smelend.smelendbackend.service.onboarding.SmeService;
import com.smelend.smelendbackend.service.underwriting.UnderwritingService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/uw")
@PreAuthorize("hasAnyRole('UNDERWRITER','ADMIN')")
public class UnderwritingController {

    private final UnderwritingService underwritingService;
    private final ApplicationService  applicationService;
    private final SmeService          smeService;
    private final PromoterService     promoterService;
    private final KycService          kycService;
    private final DocumentService     documentService;

    public UnderwritingController(UnderwritingService underwritingService,
                                  ApplicationService applicationService,
                                  SmeService smeService,
                                  PromoterService promoterService,
                                  KycService kycService,
                                  DocumentService documentService) {
        this.underwritingService = underwritingService;
        this.applicationService  = applicationService;
        this.smeService          = smeService;
        this.promoterService     = promoterService;
        this.kycService          = kycService;
        this.documentService     = documentService;
    }

    /** UW queue — all apps in ROUTED_TO_UW state */
    @GetMapping("/queue")
    public ApiResponse<List<ApplicationResponse>> queue() {
        return ApiResponse.ok("Underwriting queue fetched", underwritingService.queue());
    }

    /** UW decision — Approve / Reject / Return */
    @PostMapping("/applications/{applicationId}/decision")
    public ApiResponse<UwReviewResponse> decide(
            @PathVariable Long applicationId,
            @Valid @RequestBody UwDecisionRequest req) {
        return ApiResponse.ok("Decision recorded", underwritingService.decide(applicationId, req));
    }

    // ── Cross-Reference for Approval ──────────────────────────────

    /** UW: view full application details */
    @GetMapping("/applications/{applicationId}")
    public ApiResponse<ApplicationResponse> getApplication(@PathVariable Long applicationId) {
        return ApiResponse.ok("Application fetched", applicationService.get(applicationId));
    }

    /** UW: view SME details via loan_application_id → sme_id */
    @GetMapping("/applications/{applicationId}/sme")
    public ApiResponse<SmeResponse> getSmeForApp(@PathVariable Long applicationId) {
        ApplicationResponse app = applicationService.get(applicationId);
        return ApiResponse.ok("SME fetched", smeService.get(app.getSmeId()));
    }

    /** UW: view all KYC records for the SME linked to this application */
    @GetMapping("/applications/{applicationId}/kyc")
    public ApiResponse<List<KycResponse>> getKycForApp(@PathVariable Long applicationId) {
        ApplicationResponse app = applicationService.get(applicationId);
        return ApiResponse.ok("KYC records fetched", kycService.listBySme(app.getSmeId()));
    }

    /** UW: view promoters for the SME linked to this application */
    @GetMapping("/applications/{applicationId}/promoters")
    public ApiResponse<List<PromoterResponse>> getPromotersForApp(@PathVariable Long applicationId) {
        ApplicationResponse app = applicationService.get(applicationId);
        return ApiResponse.ok("Promoters fetched", promoterService.listBySme(app.getSmeId()));
    }

    /** UW: view uploaded documents for this application */
    @GetMapping("/applications/{applicationId}/documents")
    public ApiResponse<List<DocumentResponse>> getDocsForApp(@PathVariable Long applicationId) {
        return ApiResponse.ok("Documents fetched", documentService.list(applicationId));
    }
}