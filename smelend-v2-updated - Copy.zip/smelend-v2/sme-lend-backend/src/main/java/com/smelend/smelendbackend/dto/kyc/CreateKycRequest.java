package com.smelend.smelendbackend.dto.kyc;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CreateKycRequest {

    @NotNull
    private Long smeId;

    /** Optional: link a specific promoter to this KYC record */
    private Long promoterId;

    /** Optional: link a specific applicant (AppUser) to this KYC record */
    private Long applicantId;
}