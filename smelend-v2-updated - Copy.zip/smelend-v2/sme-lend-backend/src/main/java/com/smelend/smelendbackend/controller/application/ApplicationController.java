package com.smelend.smelendbackend.controller.application;

import com.smelend.smelendbackend.dto.ApiResponse;
import com.smelend.smelendbackend.dto.application.ApplicationResponse;
import com.smelend.smelendbackend.dto.application.CreateApplicationRequest;
import com.smelend.smelendbackend.dto.document.AddDocumentRequest;
import com.smelend.smelendbackend.dto.document.DocumentResponse;
import com.smelend.smelendbackend.entity.Document;
import com.smelend.smelendbackend.entity.enums.DocType;
import com.smelend.smelendbackend.service.application.ApplicationService;
import com.smelend.smelendbackend.service.application.DocumentService;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/applications")
public class ApplicationController {

    private final ApplicationService applicationService;
    private final DocumentService documentService;

    public ApplicationController(ApplicationService applicationService, DocumentService documentService) {
        this.applicationService = applicationService;
        this.documentService = documentService;
    }

    // ── Application CRUD ─────────────────────────────────────────────

    @PostMapping
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN')")
    public ApiResponse<ApplicationResponse> create(@Valid @RequestBody CreateApplicationRequest req) {
        return ApiResponse.ok("Application created", applicationService.create(req));
    }

    /** Applicant sees their own applications */
    @GetMapping
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN')")
    public ApiResponse<List<ApplicationResponse>> listMine() {
        return ApiResponse.ok("Applications fetched", applicationService.listMine());
    }

    /** Agent/Admin/UW sees ALL applications in the system (for KYC cross-reference) */
    @GetMapping("/all")
    @PreAuthorize("hasAnyRole('AGENT','ADMIN','UNDERWRITER')")
    public ApiResponse<List<ApplicationResponse>> listAll() {
        return ApiResponse.ok("All applications fetched", applicationService.listAll());
    }

    @GetMapping("/{applicationId}")
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN','UNDERWRITER')")
    public ApiResponse<ApplicationResponse> get(@PathVariable Long applicationId) {
        return ApiResponse.ok("Application fetched", applicationService.get(applicationId));
    }

    @PatchMapping("/{applicationId}/submit")
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN')")
    public ApiResponse<ApplicationResponse> submit(@PathVariable Long applicationId) {
        return ApiResponse.ok("Application submitted and routed to underwriter",
                applicationService.submit(applicationId));
    }

    // ── Document Management ───────────────────────────────────────────

    /** Legacy: add document via URI string */
    @PostMapping("/{applicationId}/documents")
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN')")
    public ApiResponse<DocumentResponse> addDoc(@PathVariable Long applicationId,
                                                @Valid @RequestBody AddDocumentRequest req) {
        return ApiResponse.ok("Document added", documentService.add(applicationId, req));
    }

    /** Multipart PDF upload */
    @PostMapping(value = "/{applicationId}/documents/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN')")
    public ApiResponse<DocumentResponse> uploadDoc(
            @PathVariable Long applicationId,
            @RequestParam("file") MultipartFile file,
            @RequestParam("docType") DocType docType) {
        return ApiResponse.ok("Document uploaded", documentService.uploadFile(applicationId, file, docType));
    }

    /** List documents for an application (Agent, Applicant owner, UW, Admin) */
    @GetMapping("/{applicationId}/documents")
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN','UNDERWRITER')")
    public ApiResponse<List<DocumentResponse>> listDocs(@PathVariable Long applicationId) {
        return ApiResponse.ok("Documents fetched", documentService.list(applicationId));
    }

    /** Download a specific document binary from filesystem */
    @GetMapping("/{applicationId}/documents/{documentId}/download")
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN','UNDERWRITER')")
    public ResponseEntity<byte[]> downloadDoc(@PathVariable Long applicationId,
                                              @PathVariable Long documentId) {
        // Get metadata first (for content-type and filename)
        Document meta = documentService.getDocumentMeta(applicationId, documentId);

        // Read bytes from filesystem
        byte[] bytes = documentService.downloadFile(applicationId, documentId);

        String ct    = meta.getContentType() != null ? meta.getContentType() : "application/octet-stream";
        String fname = meta.getFileName()    != null ? meta.getFileName()    : "document";

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fname + "\"")
                .contentType(MediaType.parseMediaType(ct))
                .body(bytes);
    }
}