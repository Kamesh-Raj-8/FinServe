package com.smelend.smelendbackend.dto.kyc;

import com.smelend.smelendbackend.entity.enums.KycStatus;
import lombok.*;

import java.time.LocalDate;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class KycResponse {

    private Long kycId;

    // Core FK IDs
    private Long smeId;
    private String smeLegalName;

    private Long promoterId;
    private String promoterName;

    private Long applicantId;
    private String applicantEmail;
    private String applicantFullName;

    private KycStatus verificationStatus;

    private LocalDate verifiedDate;
    private Long verifiedByUserId;
    private String verifiedByEmail;

    private String notes;
}