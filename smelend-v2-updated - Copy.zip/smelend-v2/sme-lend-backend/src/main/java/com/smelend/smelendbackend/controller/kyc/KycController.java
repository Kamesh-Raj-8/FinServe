package com.smelend.smelendbackend.controller.kyc;

import com.smelend.smelendbackend.dto.ApiResponse;
import com.smelend.smelendbackend.dto.kyc.CreateKycRequest;
import com.smelend.smelendbackend.dto.kyc.KycActionRequest;
import com.smelend.smelendbackend.dto.kyc.KycResponse;
import com.smelend.smelendbackend.service.kyc.KycService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/kyc")
public class KycController {

    private final KycService kycService;

    public KycController(KycService kycService) {
        this.kycService = kycService;
    }

    /** POST /kyc — Applicant or Agent creates a KYC record */
    @PostMapping
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN')")
    public ApiResponse<KycResponse> create(@Valid @RequestBody CreateKycRequest req) {
        return ApiResponse.ok("KYC created", kycService.create(req));
    }

    /** GET /kyc — Agent/Admin: all KYC records in the system */
    @GetMapping
    @PreAuthorize("hasAnyRole('AGENT','ADMIN')")
    public ApiResponse<List<KycResponse>> listAll() {
        return ApiResponse.ok("All KYC records fetched", kycService.listAll());
    }

    /** GET /kyc/pending — Agent/Admin: all PENDING KYC records (verification queue) */
    @GetMapping("/pending")
    @PreAuthorize("hasAnyRole('AGENT','ADMIN')")
    public ApiResponse<List<KycResponse>> listPending() {
        return ApiResponse.ok("Pending KYC queue fetched", kycService.listAllPending());
    }

    /** GET /kyc/{kycId} — fetch single KYC record with full entity detail */
    @GetMapping("/{kycId}")
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN','UNDERWRITER')")
    public ApiResponse<KycResponse> getById(@PathVariable Long kycId) {
        return ApiResponse.ok("KYC fetched", kycService.getById(kycId));
    }

    /** GET /kyc/smes/{smeId} — Applicant/Agent view KYC for specific SME */
    @GetMapping("/smes/{smeId}")
    @PreAuthorize("hasAnyRole('APPLICANT','AGENT','ADMIN','UNDERWRITER')")
    public ApiResponse<List<KycResponse>> listBySme(@PathVariable Long smeId) {
        return ApiResponse.ok("KYC list fetched", kycService.listBySme(smeId));
    }

    /** PATCH /kyc/{kycId}/verify — Agent verifies after reviewing entity details */
    @PatchMapping("/{kycId}/verify")
    @PreAuthorize("hasAnyRole('AGENT','ADMIN')")
    public ApiResponse<KycResponse> verify(@PathVariable Long kycId,
                                           @RequestBody(required = false) KycActionRequest req) {
        return ApiResponse.ok("KYC verified", kycService.verify(kycId, req));
    }

    /** PATCH /kyc/{kycId}/reject — Agent rejects KYC */
    @PatchMapping("/{kycId}/reject")
    @PreAuthorize("hasAnyRole('AGENT','ADMIN')")
    public ApiResponse<KycResponse> reject(@PathVariable Long kycId,
                                           @RequestBody(required = false) KycActionRequest req) {
        return ApiResponse.ok("KYC rejected", kycService.reject(kycId, req));
    }
}