package com.smelend.smelendbackend.dto.servicing.repayment;

import com.smelend.smelendbackend.entity.enums.RepaymentMode;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter @Setter
public class PostRepaymentRequest {

    @NotNull
    private Long loanAccountId;

    @NotNull
    @DecimalMin(value = "0.0", inclusive = false)
    private BigDecimal amount;

    @NotNull
    private RepaymentMode mode;

    private String referenceNo;

    @NotNull
    private LocalDate paymentDate;
}