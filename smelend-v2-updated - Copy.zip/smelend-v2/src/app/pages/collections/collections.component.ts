import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';
import { DelinqResponse, PtpResponse, CreatePtpRequest, PtpStatus } from '../../core/models';

@Component({
  selector: 'app-collections',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './collections.component.html'
})
export class CollectionsComponent implements OnInit {
  private api = inject(ApiService);
  private fb  = inject(FormBuilder);

  delinquencies  = signal<DelinqResponse[]>([]);
  ptps           = signal<PtpResponse[]>([]);
  loadingDelinq  = signal(false);
  loadingPtps    = signal(false);
  creatingPtp    = signal(false);
  updatingPtp    = signal(false);

  lookupAccountId = 0;
  alertMsg  = signal('');
  alertType = signal('success');

  ptpStatuses: PtpStatus[] = ['OPEN','KEPT','BROKEN','CANCELLED'];

  ptpForm = this.fb.group({
    loanAccountId:  [null as number|null, [Validators.required, Validators.min(1)]],
    promiseDate:    ['', Validators.required],
    promisedAmount: [null as number|null, [Validators.required, Validators.min(1)]],
    notes: ['']
  });
  get pf() { return this.ptpForm.controls; }

  ngOnInit() { this.loadDelinquencies(); }

  loadDelinquencies() {
    this.loadingDelinq.set(true);
    this.api.listAllDelinquencies().subscribe({
      next: r => { this.delinquencies.set(r.data ?? []); this.loadingDelinq.set(false); },
      error: () => this.loadingDelinq.set(false)
    });
  }

  loadPtps() {
    if (!this.lookupAccountId) return;
    this.loadingPtps.set(true);
    this.api.listPtps(this.lookupAccountId).subscribe({
      next: r => { this.ptps.set(r.data ?? []); this.loadingPtps.set(false); },
      error: () => this.loadingPtps.set(false)
    });
  }

  createPtp() {
    this.ptpForm.markAllAsTouched();
    if (this.ptpForm.invalid) return;
    this.creatingPtp.set(true);
    const v = this.ptpForm.value;
    const req: CreatePtpRequest = {
      loanAccountId: v.loanAccountId!,
      promiseDate: v.promiseDate!,
      promisedAmount: v.promisedAmount!,
      notes: v.notes || undefined
    };
    this.api.createPtp(req).subscribe({
      next: r => {
        this.creatingPtp.set(false);
        this.ptpForm.reset();
        this.ptps.update(l => [...l, r.data]);
        this.flash('PTP created successfully', 'success');
      },
      error: e => { this.creatingPtp.set(false); this.flash(e?.error?.message ?? 'Failed', 'danger'); }
    });
  }

  updateStatus(ptp: PtpResponse, status: PtpStatus) {
    this.updatingPtp.set(true);
    this.api.updatePtpStatus(ptp.ptpId, status).subscribe({
      next: r => {
        this.updatingPtp.set(false);
        this.ptps.update(l => l.map(p => p.ptpId === ptp.ptpId ? r.data : p));
        this.flash(`PTP #${ptp.ptpId} → ${status}`, 'success');
      },
      error: e => { this.updatingPtp.set(false); this.flash(e?.error?.message ?? 'Failed', 'danger'); }
    });
  }

  bucketColor(bucket: string): string {
    const b = bucket?.toUpperCase();
    if (b === 'X' || b === 'CURRENT') return 'bs-verified';
    if (b === '1-30') return 'bs-pending';
    if (b === '31-60') return 'bs-draft';
    if (b === '61-90') return 'bs-rejected';
    return 'bs-rejected';
  }

  ptpBadge(s: PtpStatus): string {
    if (s === 'KEPT') return 'bs-verified';
    if (s === 'OPEN') return 'bs-pending';
    if (s === 'BROKEN') return 'bs-rejected';
    return 'bs-draft';
  }

  private flash(m: string, t: string) {
    this.alertMsg.set(m); this.alertType.set(t);
    setTimeout(() => this.alertMsg.set(''), 5000);
  }
}
