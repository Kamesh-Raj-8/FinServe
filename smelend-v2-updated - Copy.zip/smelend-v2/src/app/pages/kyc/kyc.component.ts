import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';
import { AuthService } from '../../core/services/auth.service';
import {
  KycResponse, SmeResponse, PromoterResponse, AppResponse, CreateKycRequest, DocResponse
} from '../../core/models';

type DrillType = 'sme' | 'promoter' | 'applicant';

interface DrillPanel {
  kycId: number;
  type: DrillType;
  loading: boolean;
  sme?: SmeResponse;
  promoter?: PromoterResponse;
  apps?: AppResponse[];
  docs?: DocResponse[];   // documents for the SME's applications
}

@Component({
  selector: 'app-kyc',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './kyc.component.html'
})
export class KycComponent implements OnInit {
  private api  = inject(ApiService);
  private fb   = inject(FormBuilder);
  readonly auth = inject(AuthService);

  // ── Tabs ─────────────────────────────────────────────────
  tab = signal<'pending' | 'create' | 'lookup'>('pending');

  // ── Pending queue (Agent view) ────────────────────────────
  pendingList  = signal<KycResponse[]>([]);
  allKycList   = signal<KycResponse[]>([]);
  loadingQueue = signal(false);

  // ── Drill-down panels (per KYC row) ─────────────────────
  drillPanels = signal<Map<number, DrillPanel>>(new Map());

  // ── Create form ──────────────────────────────────────────
  creating = signal(false);
  createForm = this.fb.group({
    smeId:       [null as number|null, [Validators.required, Validators.min(1)]],
    promoterId:  [null as number|null],
    applicantId: [null as number|null]
  });
  get cf() { return this.createForm.controls; }

  // ── Lookup by SME ────────────────────────────────────────
  smeIdLookup  = 0;
  kycBySme     = signal<KycResponse[]>([]);
  loadingBySme = signal(false);

  // ── Verify/Reject action modal ───────────────────────────
  actionKyc  = signal<KycResponse|null>(null);
  actionType = signal<'verify'|'reject'>('verify');
  actionNotes = '';
  acting     = signal(false);

  // ── Alert ────────────────────────────────────────────────
  alertMsg  = signal('');
  alertType = signal('success');

  ngOnInit() {
    if (this.isAgent()) { this.loadPending(); }
  }

  // ── Load Methods ─────────────────────────────────────────
  loadPending() {
    this.loadingQueue.set(true);
    this.api.listPendingKyc().subscribe({
      next: r => { this.pendingList.set(r.data ?? []); this.loadingQueue.set(false); },
      error: () => this.loadingQueue.set(false)
    });
  }

  loadAllKyc() {
    this.loadingQueue.set(true);
    this.api.listAllKyc().subscribe({
      next: r => { this.allKycList.set(r.data ?? []); this.loadingQueue.set(false); },
      error: () => this.loadingQueue.set(false)
    });
  }

  loadBySme() {
    if (!this.smeIdLookup) return;
    this.loadingBySme.set(true);
    this.api.listKycBySme(this.smeIdLookup).subscribe({
      next: r => { this.kycBySme.set(r.data ?? []); this.loadingBySme.set(false); },
      error: () => this.loadingBySme.set(false)
    });
  }

  // ── Drill-down (Arrow Buttons) ────────────────────────────
  toggleDrill(kyc: KycResponse, type: DrillType) {
    const panels = new Map(this.drillPanels());
    const key = kyc.kycId * 10 + (type === 'sme' ? 0 : type === 'promoter' ? 1 : 2);

    if (panels.has(key)) {
      panels.delete(key);
      this.drillPanels.set(panels);
      return;
    }

    const panel: DrillPanel = { kycId: kyc.kycId, type, loading: true };
    panels.set(key, panel);
    this.drillPanels.set(panels);

    if (type === 'sme' && kyc.smeId) {
      this.api.getSme(kyc.smeId).subscribe({
        next: r => {
          panel.sme = r.data;
          panel.loading = false;
          panel.docs = [];
          // Load all applications for this SME, then load docs for each
          this.api.listAllApps().subscribe({
            next: a => {
              const smeApps = (a.data ?? []).filter(app => app.smeId === kyc.smeId);
              panel.apps = smeApps;
              this.drillPanels.set(new Map(panels));
              // Fetch docs for each app and merge into panel.docs
              smeApps.forEach(app => {
                this.api.listDocs(app.applicationId).subscribe({
                  next: d => {
                    panel.docs = [...(panel.docs ?? []), ...(d.data ?? [])];
                    this.drillPanels.set(new Map(panels));
                  }
                });
              });
            }
          });
          this.drillPanels.set(new Map(panels));
        },
        error: () => { panel.loading = false; this.drillPanels.set(new Map(panels)); }
      });
    } else if (type === 'promoter' && kyc.promoterId) {
      this.api.getPromoter(kyc.promoterId).subscribe({
        next: r => { panel.promoter = r.data; panel.loading = false; this.drillPanels.set(new Map(panels)); },
        error: () => { panel.loading = false; this.drillPanels.set(new Map(panels)); }
      });
    } else if (type === 'applicant' && kyc.applicantId) {
      // Applicant info already in KYC record; just mark loaded
      panel.loading = false;
      this.drillPanels.set(new Map(panels));
    }
  }

  getDrillKey(kycId: number, type: DrillType): number {
    return kycId * 10 + (type === 'sme' ? 0 : type === 'promoter' ? 1 : 2);
  }

  getDrill(kycId: number, type: DrillType): DrillPanel | undefined {
    return this.drillPanels().get(this.getDrillKey(kycId, type));
  }

  getDrillSme(kycId: number) { return this.getDrill(kycId, 'sme')?.sme ?? null; }
  getDrillPromoter(kycId: number) { return this.getDrill(kycId, 'promoter')?.promoter ?? null; }
  getDrillDocs(kycId: number): DocResponse[] { return this.getDrill(kycId, 'sme')?.docs ?? []; }
  getDrillApps(kycId: number): AppResponse[] { return this.getDrill(kycId, 'sme')?.apps ?? []; }
  isDrillLoading(kycId: number, type: DrillType) { return this.getDrill(kycId, type)?.loading ?? false; }

  isDrillOpen(kycId: number, type: DrillType): boolean {
    return this.drillPanels().has(this.getDrillKey(kycId, type));
  }

  // ── Create KYC ───────────────────────────────────────────
  createKyc() {
    this.createForm.markAllAsTouched();
    if (this.createForm.invalid) return;
    this.creating.set(true);
    const v = this.createForm.value;
    const req: CreateKycRequest = {
      smeId: v.smeId!,
      promoterId: v.promoterId ?? undefined,
      applicantId: v.applicantId ?? undefined
    };
    this.api.createKyc(req).subscribe({
      next: () => {
        this.creating.set(false);
        this.createForm.reset();
        this.flash('KYC record created', 'success');
        if (this.isAgent()) { this.loadPending(); }
      },
      error: e => { this.creating.set(false); this.flash(e?.error?.message ?? 'Failed', 'danger'); }
    });
  }

  // ── Verify / Reject Modal ────────────────────────────────
  openAction(k: KycResponse, type: 'verify'|'reject') {
    this.actionKyc.set(k); this.actionType.set(type); this.actionNotes = '';
  }

  doAction() {
    const k = this.actionKyc();
    if (!k) return;
    this.acting.set(true);
    const req = { notes: this.actionNotes || undefined };
    const obs = this.actionType() === 'verify'
      ? this.api.verifyKyc(k.kycId, req)
      : this.api.rejectKyc(k.kycId, req);

    obs.subscribe({
      next: r => {
        this.acting.set(false);
        this.actionKyc.set(null);
        // Remove from pending list since it's no longer PENDING
        this.pendingList.update(l => l.filter(i => i.kycId !== k.kycId));
        this.allKycList.update(l => l.map(i => i.kycId === k.kycId ? r.data : i));
        this.flash('KYC ' + this.actionType() + 'd', this.actionType() === 'verify' ? 'success' : 'danger');
        // Clear any open drill panels for this KYC
        const panels = new Map(this.drillPanels());
        [0, 1, 2].forEach(i => panels.delete(k.kycId * 10 + i));
        this.drillPanels.set(panels);
      },
      error: e => { this.acting.set(false); this.flash(e?.error?.message ?? 'Failed', 'danger'); }
    });
  }

  // ── Helpers ──────────────────────────────────────────────
  isAgent()   { return this.auth.hasAnyRole('AGENT', 'ADMIN'); }
  isApplicant() { return this.auth.hasAnyRole('APPLICANT'); }
  isAdminOnly() { return this.auth.hasRole('ADMIN'); }
  badgeClass(s: string) { return 'badge-status bs-' + s.toLowerCase(); }

  downloadDoc(doc: DocResponse) {
    if (!doc.downloadUrl) return;
    this.api.downloadDoc(doc.applicationId, doc.documentId).subscribe({
      next: blob => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = doc.fileName || 'document'; a.click();
        URL.revokeObjectURL(url);
      },
      error: () => this.flash('Download failed', 'danger')
    });
  }

  setTab(t: 'pending'|'create'|'lookup') {
    this.tab.set(t);
    if (t === 'pending' && this.pendingList().length === 0 && this.isAgent()) this.loadPending();
  }

  private flash(msg: string, type: string) {
    this.alertMsg.set(msg); this.alertType.set(type);
    setTimeout(() => this.alertMsg.set(''), 5000);
  }
}
