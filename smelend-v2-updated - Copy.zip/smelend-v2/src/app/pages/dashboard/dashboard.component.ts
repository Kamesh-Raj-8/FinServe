import { Component, OnInit, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { ApiService } from '../../core/services/api.service';
import { AppResponse, RoleName } from '../../core/models';

interface QuickLink { icon: string; label: string; sub: string; route: string; color: string; roles: RoleName[]; }

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit {
  readonly auth = inject(AuthService);
  private api   = inject(ApiService);

  loading = signal(true);
  stats   = signal({ total: 0, pending: 0, approved: 0, disbursed: 0 });
  apps    = signal<AppResponse[]>([]);

  private ALL_LINKS: QuickLink[] = [
    { icon: 'bi-building-add',       label: 'Register SME',       sub: 'Onboard a business',      route: '/sme/new',      color: '#2563eb', roles: ['ADMIN','APPLICANT','AGENT'] },
    { icon: 'bi-person-vcard',       label: 'KYC Management',     sub: 'Verify identity',          route: '/kyc',          color: '#0891b2', roles: ['ADMIN','APPLICANT','AGENT'] },
    { icon: 'bi-file-earmark-plus',  label: 'New Application',    sub: 'Apply for a loan',         route: '/applications/new', color: '#7c3aed', roles: ['ADMIN','APPLICANT','AGENT'] },
    { icon: 'bi-clipboard2-check',   label: 'UW Queue',           sub: 'Review applications',      route: '/underwriting', color: '#d97706', roles: ['ADMIN','UNDERWRITER'] },
    { icon: 'bi-send-check',         label: 'Operations',         sub: 'Offers & disbursements',   route: '/operations',   color: '#059669', roles: ['ADMIN','OPERATIONS'] },
    { icon: 'bi-tag',                label: 'Offers',             sub: 'View loan offers',         route: '/offers',       color: '#0891b2', roles: ['ADMIN','OPERATIONS','APPLICANT','AGENT'] },
    { icon: 'bi-calendar3',          label: 'Servicing',          sub: 'Repayment schedules',      route: '/servicing',    color: '#7c3aed', roles: ['ADMIN','OPERATIONS','SERVICING'] },
    { icon: 'bi-cash-coin',          label: 'Repayments',         sub: 'Post & track payments',    route: '/repayments',   color: '#059669', roles: ['ADMIN','OPERATIONS'] },
    { icon: 'bi-gear',               label: 'Admin Panel',        sub: 'Users, roles & products',  route: '/admin',        color: '#475569', roles: ['ADMIN'] },
  ];

  quickLinks = computed(() => {
    const role = this.auth.userRole();
    return this.ALL_LINKS.filter(l => l.roles.length === 0 || (role && l.roles.includes(role)));
  });

  ngOnInit(): void {
    if (this.auth.hasAnyRole('ADMIN','APPLICANT','AGENT')) {
      this.api.listApps().subscribe({
        next: r => {
          const d = r.data ?? [];
          this.apps.set(d.slice(0, 5));
          const total = d.length;
          const pending   = d.filter(a => ['SUBMITTED','ROUTED_TO_UW','KYC_PENDING','READY_TO_SUBMIT'].includes(a.status)).length;
          const approved  = d.filter(a => a.status === 'UW_APPROVED' || a.status === 'OFFERED' || a.status === 'OFFER_ACCEPTED').length;
          const disbursed = d.filter(a => a.status === 'DISBURSED').length;
          this.stats.set({ total, pending, approved, disbursed });
          this.loading.set(false);
        },
        error: () => this.loading.set(false)
      });
    } else {
      this.loading.set(false);
    }
  }

  formatStatus(s: string) { return s.replace(/_/g, ' '); }
  statusClass(s: string): string { return 'badge-status bs-' + s.toLowerCase(); }
}
