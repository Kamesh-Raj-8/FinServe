import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../core/services/api.service';
import { AuthService } from '../../core/services/auth.service';
import { OfferResponse } from '../../core/models';

@Component({ selector: 'app-offers', standalone: true, imports: [CommonModule], templateUrl: './offers.component.html' })
export class OffersComponent implements OnInit {
  private api = inject(ApiService); readonly auth = inject(AuthService);
  offers = signal<OfferResponse[]>([]); loading = signal(true); alertMsg = signal(''); alertType = signal('success');
  ngOnInit() { this.load(); }
  load() { this.loading.set(true); this.api.listOffers().subscribe({ next: r => { this.offers.set(r.data??[]); this.loading.set(false); }, error: () => this.loading.set(false) }); }

  accept(id: number) { this.api.acceptOffer(id).subscribe({ next: r => { this.offers.update(o => o.map(x => x.offerId === id ? r.data : x)); this.flash('Offer accepted!', 'success'); }, error: e => this.flash(e?.error?.message??'Failed', 'danger') }); }
  reject(id: number) { this.api.rejectOffer(id).subscribe({ next: r => { this.offers.update(o => o.map(x => x.offerId === id ? r.data : x)); this.flash('Offer rejected', 'warning'); }, error: e => this.flash(e?.error?.message??'Failed', 'danger') }); }

  canAct() { return this.auth.hasAnyRole('APPLICANT','AGENT','ADMIN'); }
  statusClass(s: string) { return 'badge-status bs-' + s.toLowerCase(); }
  private flash(m: string, t: string) { this.alertMsg.set(m); this.alertType.set(t); setTimeout(() => this.alertMsg.set(''), 4000); }
}
