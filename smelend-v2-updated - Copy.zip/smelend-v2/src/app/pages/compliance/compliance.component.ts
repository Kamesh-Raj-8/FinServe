import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';
import { AuditLogResponse } from '../../core/models';

@Component({
  selector: 'app-compliance',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './compliance.component.html'
})
export class ComplianceComponent implements OnInit {
  private api = inject(ApiService);

  auditLogs   = signal<AuditLogResponse[]>([]);
  filtered    = signal<AuditLogResponse[]>([]);
  loading     = signal(false);
  alertMsg    = signal('');
  alertType   = signal('success');

  filterRefType  = '';
  filterRefId    = 0;
  filterActorId  = 0;
  filterAction   = '';

  ngOnInit() { this.loadAll(); }

  loadAll() {
    this.loading.set(true);
    this.api.listAuditLogs().subscribe({
      next: r => {
        const logs = (r.data ?? []).sort((a, b) =>
          (b.createdDate ?? '').localeCompare(a.createdDate ?? ''));
        this.auditLogs.set(logs);
        this.filtered.set(logs);
        this.loading.set(false);
      },
      error: e => { this.loading.set(false); this.alertMsg.set(e?.error?.message ?? 'Failed'); this.alertType.set('danger'); }
    });
  }

  applyFilter() {
    let logs = this.auditLogs();
    if (this.filterAction) {
      logs = logs.filter(l => l.action.toLowerCase().includes(this.filterAction.toLowerCase()));
    }
    if (this.filterRefType) {
      logs = logs.filter(l => l.refType.toLowerCase().includes(this.filterRefType.toLowerCase()));
    }
    if (this.filterRefId > 0) {
      logs = logs.filter(l => l.refId === this.filterRefId);
    }
    if (this.filterActorId > 0) {
      logs = logs.filter(l => l.actorUserId === this.filterActorId);
    }
    this.filtered.set(logs);
  }

  clearFilter() {
    this.filterAction = '';
    this.filterRefType = '';
    this.filterRefId = 0;
    this.filterActorId = 0;
    this.filtered.set(this.auditLogs());
  }

  actionBadge(action: string): string {
    const a = action?.toLowerCase();
    if (a?.includes('created')) return 'bs-pending';
    if (a?.includes('verified') || a?.includes('approved') || a?.includes('accepted')) return 'bs-verified';
    if (a?.includes('rejected') || a?.includes('deleted')) return 'bs-rejected';
    if (a?.includes('updated') || a?.includes('submitted')) return 'bs-draft';
    return 'bs-draft';
  }

  formatDate(d?: string): string {
    if (!d) return '—';
    try { return new Date(d).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }); }
    catch { return d; }
  }
}
