import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../core/services/api.service';
import { PortfolioMetrics } from '../../core/models';

@Component({
  selector: 'app-risk',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './risk.component.html'
})
export class RiskComponent implements OnInit {
  private api = inject(ApiService);

  metrics  = signal<PortfolioMetrics | null>(null);
  loading  = signal(false);
  alertMsg = signal('');

  ngOnInit() { this.loadMetrics(); }

  loadMetrics() {
    this.loading.set(true);
    this.api.getPortfolioMetrics().subscribe({
      next: r => { this.metrics.set(r.data); this.loading.set(false); },
      error: e => { this.loading.set(false); this.alertMsg.set(e?.error?.message ?? 'Failed to load metrics'); }
    });
  }

  bucketEntries(): { bucket: string; count: number }[] {
    const m = this.metrics();
    if (!m?.bucketCounts) return [];
    return Object.entries(m.bucketCounts).map(([bucket, count]) => ({ bucket, count }));
  }

  delinquencyRate(): string {
    const m = this.metrics();
    if (!m || m.totalLoanAccounts === 0) return '0.00';
    return ((m.delinquentLoanAccounts / m.totalLoanAccounts) * 100).toFixed(2);
  }

  bucketBarWidth(count: number): number {
    const m = this.metrics();
    if (!m || m.totalLoanAccounts === 0) return 0;
    return Math.round((count / m.totalLoanAccounts) * 100);
  }

  bucketColor(bucket: string): string {
    const b = bucket?.toUpperCase();
    if (b === 'CURRENT' || b === 'X') return '#198754';
    if (b?.includes('1-30')) return '#ffc107';
    if (b?.includes('31-60')) return '#fd7e14';
    return '#dc3545';
  }
}
