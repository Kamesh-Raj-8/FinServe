import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';
import { AppResponse } from '../../../core/models';

@Component({ selector: 'app-app-list', standalone: true, imports: [CommonModule, RouterLink], templateUrl: './app-list.component.html' })
export class AppListComponent implements OnInit {
  private api = inject(ApiService);
  readonly auth = inject(AuthService);
  apps = signal<AppResponse[]>([]); loading = signal(true);
  ngOnInit() {
    this.api.listApps().subscribe({
      next: r => { this.apps.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
  formatStatus(s: string) { return s.replace(/_/g, ' '); }
  statusClass(s: string) { return 'badge-status bs-' + s.toLowerCase(); }
  isAdmin() { return this.auth.hasRole('ADMIN'); }
}
