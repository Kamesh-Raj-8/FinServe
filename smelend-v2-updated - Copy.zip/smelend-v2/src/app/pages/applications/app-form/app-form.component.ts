import { Component, OnInit, signal, computed, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';
import { LoanProductResponse } from '../../../core/models';

@Component({
  selector: 'app-app-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './app-form.component.html'
})
export class AppFormComponent implements OnInit {
  private fb     = inject(FormBuilder);
  private api    = inject(ApiService);
  private router = inject(Router);
  private route  = inject(ActivatedRoute);
  readonly auth  = inject(AuthService);

  loading  = signal(false);
  error    = signal('');
  products = signal<LoanProductResponse[]>([]);

  form = this.fb.group({
    smeId:           [null as number | null, [Validators.required, Validators.min(1)]],
    productId:       [null as number | null, Validators.required],
    requestedAmount: [null as number | null, [Validators.required, Validators.min(1)]],
    tenorMonths:     [null as number | null, [Validators.required, Validators.min(1)]],
    purposeNote:     ['']
  });
  get f() { return this.form.controls; }
  isAdmin() { return this.auth.hasRole('ADMIN'); }

  selectedProduct = computed(() => {
    const pid = this.form.controls['productId'].value;
    return pid ? this.products().find(p => p.productId === Number(pid)) ?? null : null;
  });

  ngOnInit(): void {
    this.route.queryParams.subscribe(p => {
      if (p['smeId']) this.form.patchValue({ smeId: Number(p['smeId']) });
    });
    this.api.listActiveProducts().subscribe({
      next: r => this.products.set(r.data ?? []),
      error: () => this.error.set('Unable to load loan products. Please try again.')
    });
  }

  submit(): void {
    if (this.isAdmin()) return;
    this.form.markAllAsTouched();
    if (this.form.invalid) return;
    this.loading.set(true); this.error.set('');
    const v = this.form.value;
    this.api.createApp({
      smeId: v.smeId!, productId: Number(v.productId!),
      requestedAmount: v.requestedAmount!, tenorMonths: v.tenorMonths!,
      purposeNote: v.purposeNote || undefined
    }).subscribe({
      next: r  => { this.loading.set(false); this.router.navigate(['/applications', r.data.applicationId]); },
      error: e => { this.loading.set(false); this.error.set(e?.error?.message ?? 'Failed to create application'); }
    });
  }
}
