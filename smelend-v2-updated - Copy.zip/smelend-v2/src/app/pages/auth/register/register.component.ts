import { Component, signal, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './register.component.html'
})
export class RegisterComponent {
  private fb = inject(FormBuilder); private auth = inject(AuthService); private router = inject(Router);
  loading = signal(false); error = signal(''); success = signal('');
  form = this.fb.group({
    fullName:     ['', Validators.required],
    email:        ['', [Validators.required, Validators.email]],
    password:     ['', [Validators.required, Validators.minLength(6)]],
    phone:        [''],
    bankAccountNo:[''],
    ifsc:         ['']
  });
  get f() { return this.form.controls; }

  submit() {
    this.form.markAllAsTouched(); if (this.form.invalid) return;
    this.loading.set(true); this.error.set(''); this.success.set('');
    const v = this.form.value;
    this.auth.register({
      fullName: v.fullName!, email: v.email!, password: v.password!,
      phone: v.phone || undefined, role: 'APPLICANT',
      bankAccountNo: v.bankAccountNo || undefined, ifsc: v.ifsc?.toUpperCase() || undefined
    }).subscribe({
      next: () => { this.loading.set(false); this.success.set('Account created! Redirecting…'); setTimeout(() => this.router.navigate(['/dashboard']), 1200); },
      error: e => { this.loading.set(false); this.error.set(e?.error?.message ?? 'Registration failed'); }
    });
  }
}
