import { Component, signal, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  private fb = inject(FormBuilder); private auth = inject(AuthService); private router = inject(Router);
  loading = signal(false); error = signal(''); showPwd = signal(false);
  form = this.fb.group({ email: ['', [Validators.required, Validators.email]], password: ['', Validators.required] });
  get f() { return this.form.controls; }

  demos = [
    { role: 'ADMIN',        email: 'admin@smelend.com',       password: 'Admin@123', cls: 'bs-admin' },
    { role: 'AGENT',        email: 'agent1@test.com',         password: 'Pass@123',  cls: 'bs-agent' },
    { role: 'UNDERWRITER',  email: 'underwriter1@test.com',   password: 'Pass@123',  cls: 'bs-underwriter' },
    { role: 'OPERATIONS',   email: 'operations1@test.com',    password: 'Pass@123',  cls: 'bs-operations' },
    { role: 'SERVICING',    email: 'servicing1@test.com',     password: 'Pass@123',  cls: 'bs-servicing' },
    { role: 'COLLECTIONS',  email: 'collections1@test.com',   password: 'Pass@123',  cls: 'bs-collections' },
    { role: 'RISK',         email: 'risk1@test.com',          password: 'Pass@123',  cls: 'bs-risk' },
    { role: 'COMPLIANCE',   email: 'compliance1@test.com',    password: 'Pass@123',  cls: 'bs-compliance' },
  ];

  fill(email: string, password: string) { this.form.setValue({ email, password }); }
  chipClass(cls: string) { return cls.replace("bs-", ""); }
  togglePwd() { this.showPwd.update(v => !v); }

  submit() {
    this.form.markAllAsTouched(); if (this.form.invalid) return;
    this.loading.set(true); this.error.set('');
    this.auth.login({ email: this.form.value.email!, password: this.form.value.password! }).subscribe({
      next: () => { this.loading.set(false); this.router.navigate(['/dashboard']); },
      error: e => { this.loading.set(false); this.error.set(e?.error?.message ?? 'Invalid credentials'); }
    });
  }
}
