import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';
import { AppResponse, DisburseMode, DisburseResponse } from '../../core/models';

@Component({ selector: 'app-operations', standalone: true, imports: [CommonModule, ReactiveFormsModule], templateUrl: './operations.component.html' })
export class OperationsComponent implements OnInit {
  private api = inject(ApiService); private fb = inject(FormBuilder);
  tab = signal(0);
  approvedApps = signal<AppResponse[]>([]); loading = signal(true);
  selectedApp = signal<AppResponse|null>(null); creatingOffer = signal(false);
  disbursing = signal(false); disburseResult = signal<DisburseResponse|null>(null);
  alertMsg = signal(''); alertType = signal('success');
  modes: DisburseMode[] = ['NEFT','IMPS','UPI'];

  offerForm = this.fb.group({ sanctionedAmount: [null as number|null, [Validators.required, Validators.min(1)]], interestRate: [null as number|null, [Validators.required, Validators.min(0.01)]], emiAmount: [null as number|null, [Validators.required, Validators.min(1)]], validUntil: ['', Validators.required] });
  disburseForm = this.fb.group({ applicationId: [null as number|null, [Validators.required, Validators.min(1)]], mode: ['UPI', Validators.required], transactionRef: [''], disbursementDate: [new Date().toISOString().substring(0,10), Validators.required] });
  get of() { return this.offerForm.controls; } get df() { return this.disburseForm.controls; }

  ngOnInit() { this.load(); }
  load() { this.loading.set(true); this.api.listApprovedApps().subscribe({ next: r => { this.approvedApps.set(r.data??[]); this.loading.set(false); }, error: () => this.loading.set(false) }); }

  createOffer() {
    this.offerForm.markAllAsTouched(); if (this.offerForm.invalid || !this.selectedApp()) return;
    this.creatingOffer.set(true);
    const v = this.offerForm.value;
    this.api.createOffer(this.selectedApp()!.applicationId, { sanctionedAmount: v.sanctionedAmount!, interestRate: v.interestRate!, emiAmount: v.emiAmount!, validUntil: v.validUntil! }).subscribe({
      next: r => { this.creatingOffer.set(false); this.selectedApp.set(null); this.offerForm.reset(); this.flash(`Offer #${r.data.offerId} created`, 'success'); },
      error: e => { this.creatingOffer.set(false); this.flash(e?.error?.message??'Failed', 'danger'); }
    });
  }

  disburse() {
    this.disburseForm.markAllAsTouched(); if (this.disburseForm.invalid) return;
    this.disbursing.set(true); this.disburseResult.set(null);
    const v = this.disburseForm.value;
    this.api.disburse(v.applicationId!, { mode: v.mode as DisburseMode, transactionRef: v.transactionRef||undefined, disbursementDate: v.disbursementDate! }).subscribe({
      next: r => { this.disbursing.set(false); this.disburseResult.set(r.data); this.flash(`Loan Account #${r.data.loanAccount.loanAccountId} created`, 'success'); },
      error: e => { this.disbursing.set(false); this.flash(e?.error?.message??'Disbursement failed', 'danger'); }
    });
  }

  statusClass(s: string) { return 'badge-status bs-' + s.toLowerCase(); }
  private flash(m: string, t: string) { this.alertMsg.set(m); this.alertType.set(t); setTimeout(() => this.alertMsg.set(''), 5000); }
}
