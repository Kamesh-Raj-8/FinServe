import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ApiService } from '../../core/services/api.service';
import {
  AppResponse, UwDecision, SmeResponse, PromoterResponse, KycResponse, DocResponse
} from '../../core/models';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-underwriting',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './underwriting.component.html'
})
export class UnderwritingComponent implements OnInit {
  private api  = inject(ApiService);
  private http = inject(HttpClient);
  private fb   = inject(FormBuilder);
  private B    = environment.apiUrl;

  queue    = signal<AppResponse[]>([]);
  loading  = signal(true);
  selected = signal<AppResponse|null>(null);

  // Cross-reference data loaded when an app is selected
  smeDetail    = signal<SmeResponse|null>(null);
  promoters    = signal<PromoterResponse[]>([]);
  kycRecords   = signal<KycResponse[]>([]);
  documents    = signal<DocResponse[]>([]);
  loadingRef   = signal(false);
  activeTab    = signal<'details'|'sme'|'kyc'|'promoters'|'docs'>('details');

  deciding  = signal(false);
  alertMsg  = signal('');
  alertType = signal('success');

  decisions = [
    { value: 'APPROVE', label: 'Approve',      color: 'btn-success' },
    { value: 'REJECT',  label: 'Reject',       color: 'btn-danger'  },
    { value: 'RETURN',  label: 'Return to App', color: 'btn-warning' }
  ];

  form = this.fb.group({
    decision:    ['APPROVE', Validators.required],
    summaryNote: ['']
  });
  get f() { return this.form.controls; }

  ngOnInit() { this.load(); }

  load() {
    this.loading.set(true);
    this.api.getUwQueue().subscribe({
      next: r => { this.queue.set(r.data ?? []); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }

  select(a: AppResponse) {
    this.selected.set(a);
    this.form.reset({ decision: 'APPROVE' });
    this.activeTab.set('details');
    this.loadCrossReference(a.applicationId);
  }

  loadCrossReference(appId: number) {
    this.loadingRef.set(true);
    this.smeDetail.set(null);
    this.promoters.set([]);
    this.kycRecords.set([]);
    this.documents.set([]);

    // SME
    this.http.get<any>(`${this.B}/uw/applications/${appId}/sme`).subscribe({
      next: r => this.smeDetail.set(r.data),
      error: () => {}
    });
    // KYC
    this.http.get<any>(`${this.B}/uw/applications/${appId}/kyc`).subscribe({
      next: r => this.kycRecords.set(r.data ?? []),
      error: () => {}
    });
    // Promoters
    this.http.get<any>(`${this.B}/uw/applications/${appId}/promoters`).subscribe({
      next: r => this.promoters.set(r.data ?? []),
      error: () => {}
    });
    // Documents
    this.http.get<any>(`${this.B}/uw/applications/${appId}/documents`).subscribe({
      next: r => { this.documents.set(r.data ?? []); this.loadingRef.set(false); },
      error: () => this.loadingRef.set(false)
    });
  }

  decide() {
    this.form.markAllAsTouched();
    if (this.form.invalid || !this.selected()) return;
    this.deciding.set(true);
    const v = this.form.value;
    this.api.submitUwDecision(this.selected()!.applicationId, {
      decision: v.decision as UwDecision,
      summaryNote: v.summaryNote || undefined
    }).subscribe({
      next: r => {
        this.deciding.set(false);
        this.queue.update(q => q.filter(a => a.applicationId !== this.selected()!.applicationId));
        this.selected.set(null);
        const d = r.data.decision;
        this.flash(`Decision: ${d} — Status → ${r.data.newApplicationStatus}`,
          d === 'APPROVE' ? 'success' : d === 'REJECT' ? 'danger' : 'warning');
      },
      error: e => { this.deciding.set(false); this.flash(e?.error?.message ?? 'Failed', 'danger'); }
    });
  }

  downloadDoc(doc: DocResponse) {
    if (!doc.downloadUrl) return;
    this.api.downloadDoc(this.selected()!.applicationId, doc.documentId).subscribe({
      next: blob => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = doc.fileName || 'document'; a.click();
        URL.revokeObjectURL(url);
      }
    });
  }

  statusClass(s: string) { return 'badge-status bs-' + s.toLowerCase(); }
  kycBadge(s: string)    { return 'badge-status bs-' + s.toLowerCase(); }

  private flash(m: string, t: string) {
    this.alertMsg.set(m); this.alertType.set(t);
    setTimeout(() => this.alertMsg.set(''), 6000);
  }
}
