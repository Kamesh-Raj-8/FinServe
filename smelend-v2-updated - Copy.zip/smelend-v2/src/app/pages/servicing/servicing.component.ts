import { Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';
import { ScheduleResponse, LoanAccountResponse } from '../../core/models';

@Component({ selector: 'app-servicing', standalone: true, imports: [CommonModule, FormsModule], templateUrl: './servicing.component.html' })
export class ServicingComponent {
  private api = inject(ApiService);
  loanAccId = 0; schedule = signal<ScheduleResponse[]>([]); loanAcc = signal<LoanAccountResponse|null>(null);
  loading = signal(false); error = signal('');

  load() {
    if (!this.loanAccId) return;
    this.loading.set(true); this.error.set('');
    this.api.getSchedule(this.loanAccId).subscribe({ next: r => { this.schedule.set(r.data??[]); this.loading.set(false); }, error: e => { this.error.set(e?.error?.message??'Failed'); this.loading.set(false); } });
    this.api.getLoanAccount(this.loanAccId).subscribe({ next: r => this.loanAcc.set(r.data), error: () => {} });
  }

  totalDue()  { return this.schedule().reduce((s, r) => s + r.totalDue, 0); }
  totalPaid() { return this.schedule().reduce((s, r) => s + r.amountPaid, 0); }
  totalBal()  { return this.schedule().reduce((s, r) => s + r.balanceDue, 0); }
  paidPct()   { const t = this.totalDue(); return t > 0 ? Math.round(this.totalPaid() / t * 100) : 0; }
  statusClass(s: string) { return 'badge-status bs-' + s.toLowerCase(); }
}
