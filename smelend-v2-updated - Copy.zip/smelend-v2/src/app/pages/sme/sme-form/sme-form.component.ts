import { Component, signal, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';
import { BizType } from '../../../core/models';

@Component({ selector: 'app-sme-form', standalone: true, imports: [CommonModule, ReactiveFormsModule, RouterLink], templateUrl: './sme-form.component.html' })
export class SmeFormComponent {
  private fb     = inject(FormBuilder);
  private api    = inject(ApiService);
  private router = inject(Router);
  readonly auth  = inject(AuthService);

  loading  = signal(false);
  error    = signal('');
  bizTypes: BizType[] = ['PROPRIETORSHIP','PARTNERSHIP','PVT_LTD','LLP','OTHER'];

  form = this.fb.group({
    legalName:    ['', Validators.required],
    tradeName:    [''],
    businessType: ['PROPRIETORSHIP', Validators.required],
    industry:     ['', Validators.required],
    address:      ['', Validators.required],
    gstNo:        ['']
  });
  get f() { return this.form.controls; }
  isAdmin() { return this.auth.hasRole('ADMIN'); }

  submit() {
    if (this.isAdmin()) return;
    this.form.markAllAsTouched();
    if (this.form.invalid) return;
    this.loading.set(true); this.error.set('');
    const v = this.form.value;
    this.api.createSme({
      legalName: v.legalName!, tradeName: v.tradeName || undefined,
      businessType: v.businessType as BizType, industry: v.industry!,
      address: v.address!, gstNo: v.gstNo?.toUpperCase() || undefined
    }).subscribe({
      next: r  => { this.loading.set(false); this.router.navigate(['/sme', r.data.smeId]); },
      error: e => { this.loading.set(false); this.error.set(e?.error?.message ?? 'Failed to register SME'); }
    });
  }
}
