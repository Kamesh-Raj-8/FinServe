import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../../core/services/api.service';
import { AuthService } from '../../../core/services/auth.service';
import { SmeResponse } from '../../../core/models';

@Component({ selector: 'app-sme-list', standalone: true, imports: [CommonModule, RouterLink], templateUrl: './sme-list.component.html' })
export class SmeListComponent implements OnInit {
  private api = inject(ApiService);
  readonly auth = inject(AuthService);
  all = signal<SmeResponse[]>([]); filtered = signal<SmeResponse[]>([]); loading = signal(true);
  ngOnInit() {
    this.api.listSmes().subscribe({ next: r => { this.all.set(r.data ?? []); this.filtered.set(r.data ?? []); this.loading.set(false); }, error: () => this.loading.set(false) });
  }
  search(e: Event) {
    const q = (e.target as HTMLInputElement).value.toLowerCase();
    this.filtered.set(this.all().filter(s => s.legalName.toLowerCase().includes(q) || s.industry.toLowerCase().includes(q) || (s.tradeName ?? '').toLowerCase().includes(q)));
  }
  badgeClass(s: string) { return 'badge-status bs-' + s.toLowerCase(); }
  isAdmin() { return this.auth.hasRole('ADMIN'); }
}
