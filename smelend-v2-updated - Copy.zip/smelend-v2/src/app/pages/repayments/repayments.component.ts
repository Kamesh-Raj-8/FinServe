import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';
import { RepayResponse, RepayMode } from '../../core/models';

@Component({
  selector: 'app-repayments',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './repayments.component.html'
})
export class RepaymentsComponent implements OnInit {
  private api = inject(ApiService);
  private fb  = inject(FormBuilder);

  tab         = signal(0);
  repayments  = signal<RepayResponse[]>([]);
  loadingList = signal(false);
  posting     = signal(false);
  loanAccId   = 0;
  alertMsg    = signal('');
  alertType   = signal('success');

  modes: RepayMode[] = ['UPI','NEFT','IMPS','RTGS','CASH','OTHER'];

  /** POST /servicing/repayments
   *  Fields: loanAccountId, amount, mode, referenceNo, paymentDate */
  postForm = this.fb.group({
    loanAccountId: [null as number | null, [Validators.required, Validators.min(1)]],
    amount:        [null as number | null, [Validators.required, Validators.min(0.01)]],
    mode:          ['UPI', Validators.required],
    referenceNo:   [''],
    paymentDate:   [new Date().toISOString().substring(0, 10), Validators.required]
  });
  get pf() { return this.postForm.controls; }

  ngOnInit(): void { /* nothing to pre-load */ }

  /** GET /servicing/repayments/loan-accounts/{loanAccountId} */
  loadHistory(): void {
    if (!this.loanAccId) return;
    this.loadingList.set(true);
    this.api.listRepayments(this.loanAccId).subscribe({
      next: r  => { this.repayments.set(r.data ?? []); this.loadingList.set(false); },
      error: () => this.loadingList.set(false)
    });
  }

  post(): void {
    this.postForm.markAllAsTouched();
    if (this.postForm.invalid) return;
    this.posting.set(true);
    const v = this.postForm.value;
    this.api.postRepayment({
      loanAccountId: v.loanAccountId!,
      amount:        v.amount!,
      mode:          v.mode as RepayMode,
      referenceNo:   v.referenceNo || undefined,
      paymentDate:   v.paymentDate!
    }).subscribe({
      next: r => {
        this.posting.set(false);
        this.flash(`Repayment ₹${r.data.amount} posted  Ref: ${r.data.referenceNo ?? 'N/A'}`, 'success');
        // refresh history if same account open
        if (this.loanAccId === v.loanAccountId) {
          this.repayments.update(l => [r.data, ...l]);
        }
        this.postForm.patchValue({ amount: null, referenceNo: '' });
      },
      error: e => { this.posting.set(false); this.flash(e?.error?.message ?? 'Failed', 'danger'); }
    });
  }

  private flash(m: string, t: string): void {
    this.alertMsg.set(m); this.alertType.set(t);
    setTimeout(() => this.alertMsg.set(''), 5000);
  }
}
