import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  ApiResponse, SmeResponse, CreateSmeRequest, UpdateSmeRequest,
  PromoterResponse, AddPromoterRequest, KycResponse, CreateKycRequest, KycActionRequest,
  AppResponse, CreateAppRequest, DocResponse, AddDocRequest,
  LoanProductResponse, LoanProductRequest, StatusFlag,
  UwReviewResponse, UwDecisionRequest, OfferResponse, CreateOfferRequest,
  DisburseResponse, DisburseRequest, LoanAccountResponse,
  ScheduleResponse, RepayResponse, PostRepayRequest,
  DelinqResponse, PtpResponse, CreatePtpRequest, PtpStatus,
  PortfolioMetrics, AuditLogResponse, UserResponse, CreateUserRequest, RoleResponse,
  DocType
} from '../models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly B = environment.apiUrl;
  constructor(private http: HttpClient) {}

  // ── SME ──────────────────────────────────────────────────────────
  createSme(b: CreateSmeRequest): Observable<ApiResponse<SmeResponse>> {
    return this.http.post<ApiResponse<SmeResponse>>(`${this.B}/onboarding/smes`, b);
  }
  updateSme(id: number, b: UpdateSmeRequest): Observable<ApiResponse<SmeResponse>> {
    return this.http.put<ApiResponse<SmeResponse>>(`${this.B}/onboarding/smes/${id}`, b);
  }
  listSmes(): Observable<ApiResponse<SmeResponse[]>> {
    return this.http.get<ApiResponse<SmeResponse[]>>(`${this.B}/onboarding/smes`);
  }
  getSme(id: number): Observable<ApiResponse<SmeResponse>> {
    return this.http.get<ApiResponse<SmeResponse>>(`${this.B}/onboarding/smes/${id}`);
  }

  // ── PROMOTERS ────────────────────────────────────────────────────
  addPromoter(smeId: number, b: AddPromoterRequest): Observable<ApiResponse<PromoterResponse>> {
    return this.http.post<ApiResponse<PromoterResponse>>(`${this.B}/onboarding/smes/${smeId}/promoters`, b);
  }
  listPromoters(smeId: number): Observable<ApiResponse<PromoterResponse[]>> {
    return this.http.get<ApiResponse<PromoterResponse[]>>(`${this.B}/onboarding/smes/${smeId}/promoters`);
  }
  getPromoter(id: number): Observable<ApiResponse<PromoterResponse>> {
    return this.http.get<ApiResponse<PromoterResponse>>(`${this.B}/onboarding/promoters/${id}`);
  }

  // ── KYC ──────────────────────────────────────────────────────────
  createKyc(b: CreateKycRequest): Observable<ApiResponse<KycResponse>> {
    return this.http.post<ApiResponse<KycResponse>>(`${this.B}/kyc`, b);
  }
  /** Agent/Admin: all KYC records */
  listAllKyc(): Observable<ApiResponse<KycResponse[]>> {
    return this.http.get<ApiResponse<KycResponse[]>>(`${this.B}/kyc`);
  }
  /** Agent/Admin: only PENDING KYC (verification queue) */
  listPendingKyc(): Observable<ApiResponse<KycResponse[]>> {
    return this.http.get<ApiResponse<KycResponse[]>>(`${this.B}/kyc/pending`);
  }
  getKyc(id: number): Observable<ApiResponse<KycResponse>> {
    return this.http.get<ApiResponse<KycResponse>>(`${this.B}/kyc/${id}`);
  }
  listKycBySme(smeId: number): Observable<ApiResponse<KycResponse[]>> {
    return this.http.get<ApiResponse<KycResponse[]>>(`${this.B}/kyc/smes/${smeId}`);
  }
  verifyKyc(kycId: number, b?: KycActionRequest): Observable<ApiResponse<KycResponse>> {
    return this.http.patch<ApiResponse<KycResponse>>(`${this.B}/kyc/${kycId}/verify`, b ?? {});
  }
  rejectKyc(kycId: number, b?: KycActionRequest): Observable<ApiResponse<KycResponse>> {
    return this.http.patch<ApiResponse<KycResponse>>(`${this.B}/kyc/${kycId}/reject`, b ?? {});
  }

  // ── APPLICATIONS ─────────────────────────────────────────────────
  createApp(b: CreateAppRequest): Observable<ApiResponse<AppResponse>> {
    return this.http.post<ApiResponse<AppResponse>>(`${this.B}/applications`, b);
  }
  listApps(): Observable<ApiResponse<AppResponse[]>> {
    return this.http.get<ApiResponse<AppResponse[]>>(`${this.B}/applications`);
  }
  /** Agent/Admin/UW: all applications */
  listAllApps(): Observable<ApiResponse<AppResponse[]>> {
    return this.http.get<ApiResponse<AppResponse[]>>(`${this.B}/applications/all`);
  }
  getApp(id: number): Observable<ApiResponse<AppResponse>> {
    return this.http.get<ApiResponse<AppResponse>>(`${this.B}/applications/${id}`);
  }
  submitApp(id: number): Observable<ApiResponse<AppResponse>> {
    return this.http.patch<ApiResponse<AppResponse>>(`${this.B}/applications/${id}/submit`, {});
  }

  // ── DOCUMENTS ────────────────────────────────────────────────────
  /** Legacy URI-based doc add */
  addDoc(appId: number, b: AddDocRequest): Observable<ApiResponse<DocResponse>> {
    return this.http.post<ApiResponse<DocResponse>>(`${this.B}/applications/${appId}/documents`, b);
  }
  listDocs(appId: number): Observable<ApiResponse<DocResponse[]>> {
    return this.http.get<ApiResponse<DocResponse[]>>(`${this.B}/applications/${appId}/documents`);
  }
  /** Multipart PDF upload */
  uploadDoc(appId: number, file: File, docType: DocType): Observable<ApiResponse<DocResponse>> {
    const fd = new FormData();
    fd.append('file', file);
    fd.append('docType', docType);
    return this.http.post<ApiResponse<DocResponse>>(
      `${this.B}/applications/${appId}/documents/upload`, fd);
  }
  /** Download document binary — returns blob */
  downloadDoc(appId: number, docId: number): Observable<Blob> {
    return this.http.get(
      `${this.B}/applications/${appId}/documents/${docId}/download`,
      { responseType: 'blob' }
    );
  }

  // ── ADMIN ─────────────────────────────────────────────────────────
  listRoles(): Observable<ApiResponse<RoleResponse[]>> {
    return this.http.get<ApiResponse<RoleResponse[]>>(`${this.B}/admin/roles`);
  }
  createUser(b: CreateUserRequest): Observable<ApiResponse<UserResponse>> {
    return this.http.post<ApiResponse<UserResponse>>(`${this.B}/admin/users`, b);
  }
  listUsers(): Observable<ApiResponse<UserResponse[]>> {
    return this.http.get<ApiResponse<UserResponse[]>>(`${this.B}/admin/users`);
  }
  setUserStatus(uid: number, status: StatusFlag): Observable<ApiResponse<UserResponse>> {
    return this.http.patch<ApiResponse<UserResponse>>(
      `${this.B}/admin/users/${uid}/status`, {},
      { params: new HttpParams().set('status', status) }
    );
  }
  createProduct(b: LoanProductRequest): Observable<ApiResponse<LoanProductResponse>> {
    return this.http.post<ApiResponse<LoanProductResponse>>(`${this.B}/admin/loan-products`, b);
  }
  listProducts(): Observable<ApiResponse<LoanProductResponse[]>> {
    return this.http.get<ApiResponse<LoanProductResponse[]>>(`${this.B}/admin/loan-products`);
  }
  listActiveProducts(): Observable<ApiResponse<LoanProductResponse[]>> {
    return this.http.get<ApiResponse<LoanProductResponse[]>>(`${this.B}/loan-products`);
  }
  updateProduct(id: number, b: LoanProductRequest): Observable<ApiResponse<LoanProductResponse>> {
    return this.http.put<ApiResponse<LoanProductResponse>>(`${this.B}/admin/loan-products/${id}`, b);
  }
  setProductStatus(id: number, status: StatusFlag): Observable<ApiResponse<LoanProductResponse>> {
    return this.http.patch<ApiResponse<LoanProductResponse>>(
      `${this.B}/admin/loan-products/${id}/status`, {},
      { params: new HttpParams().set('status', status) }
    );
  }
  deleteProduct(id: number): Observable<ApiResponse<void>> {
    return this.http.delete<ApiResponse<void>>(`${this.B}/admin/loan-products/${id}`);
  }

  // ── ADMIN MONITOR (GET-only cross-role data) ──────────────────────
  monitorAllKyc(): Observable<ApiResponse<KycResponse[]>> {
    return this.http.get<ApiResponse<KycResponse[]>>(`${this.B}/admin/monitor/kyc`);
  }
  monitorAllApps(): Observable<ApiResponse<AppResponse[]>> {
    return this.http.get<ApiResponse<AppResponse[]>>(`${this.B}/admin/monitor/applications`);
  }
  monitorRiskMetrics(): Observable<ApiResponse<PortfolioMetrics>> {
    return this.http.get<ApiResponse<PortfolioMetrics>>(`${this.B}/admin/monitor/risk/metrics`);
  }
  monitorAuditLogs(): Observable<ApiResponse<AuditLogResponse[]>> {
    return this.http.get<ApiResponse<AuditLogResponse[]>>(`${this.B}/admin/monitor/audit-logs`);
  }
  monitorDelinquencies(): Observable<ApiResponse<DelinqResponse[]>> {
    return this.http.get<ApiResponse<DelinqResponse[]>>(`${this.B}/admin/monitor/delinquencies`);
  }

  // ── UNDERWRITING ─────────────────────────────────────────────────
  getUwQueue(): Observable<ApiResponse<AppResponse[]>> {
    return this.http.get<ApiResponse<AppResponse[]>>(`${this.B}/uw/queue`);
  }
  submitUwDecision(appId: number, b: UwDecisionRequest): Observable<ApiResponse<UwReviewResponse>> {
    return this.http.post<ApiResponse<UwReviewResponse>>(`${this.B}/uw/applications/${appId}/decision`, b);
  }

  // ── OPERATIONS ───────────────────────────────────────────────────
  listApprovedApps(): Observable<ApiResponse<AppResponse[]>> {
    return this.http.get<ApiResponse<AppResponse[]>>(`${this.B}/ops/applications/approved`);
  }
  getOpsApp(id: number): Observable<ApiResponse<AppResponse>> {
    return this.http.get<ApiResponse<AppResponse>>(`${this.B}/ops/applications/${id}`);
  }

  // ── OFFERS ───────────────────────────────────────────────────────
  createOffer(appId: number, b: CreateOfferRequest): Observable<ApiResponse<OfferResponse>> {
    return this.http.post<ApiResponse<OfferResponse>>(`${this.B}/offers/applications/${appId}`, b);
  }
  listOffers(): Observable<ApiResponse<OfferResponse[]>> {
    return this.http.get<ApiResponse<OfferResponse[]>>(`${this.B}/offers`);
  }
  acceptOffer(id: number): Observable<ApiResponse<OfferResponse>> {
    return this.http.patch<ApiResponse<OfferResponse>>(`${this.B}/offers/${id}/accept`, {});
  }
  rejectOffer(id: number): Observable<ApiResponse<OfferResponse>> {
    return this.http.patch<ApiResponse<OfferResponse>>(`${this.B}/offers/${id}/reject`, {});
  }

  // ── DISBURSEMENT ─────────────────────────────────────────────────
  disburse(appId: number, b: DisburseRequest): Observable<ApiResponse<DisburseResponse>> {
    return this.http.post<ApiResponse<DisburseResponse>>(`${this.B}/ops/applications/${appId}/disburse`, b);
  }
  getLoanAccount(id: number): Observable<ApiResponse<LoanAccountResponse>> {
    return this.http.get<ApiResponse<LoanAccountResponse>>(`${this.B}/ops/loan-accounts/${id}`);
  }

  // ── SERVICING ────────────────────────────────────────────────────
  getSchedule(loanAccountId: number): Observable<ApiResponse<ScheduleResponse[]>> {
    return this.http.get<ApiResponse<ScheduleResponse[]>>(`${this.B}/servicing/loan-accounts/${loanAccountId}/schedule`);
  }
  postRepayment(b: PostRepayRequest): Observable<ApiResponse<RepayResponse>> {
    return this.http.post<ApiResponse<RepayResponse>>(`${this.B}/servicing/repayments`, b);
  }
  listRepayments(loanAccountId: number): Observable<ApiResponse<RepayResponse[]>> {
    return this.http.get<ApiResponse<RepayResponse[]>>(`${this.B}/servicing/repayments/loan-accounts/${loanAccountId}`);
  }

  // ── COLLECTIONS ──────────────────────────────────────────────────
  listAllDelinquencies(): Observable<ApiResponse<DelinqResponse[]>> {
    return this.http.get<ApiResponse<DelinqResponse[]>>(`${this.B}/collections/delinquencies`);
  }
  getDelinquency(loanAccountId: number): Observable<ApiResponse<DelinqResponse>> {
    return this.http.get<ApiResponse<DelinqResponse>>(`${this.B}/collections/loan-accounts/${loanAccountId}/delinquency`);
  }
  createPtp(b: CreatePtpRequest): Observable<ApiResponse<PtpResponse>> {
    return this.http.post<ApiResponse<PtpResponse>>(`${this.B}/collections/ptp`, b);
  }
  listPtps(loanAccountId: number): Observable<ApiResponse<PtpResponse[]>> {
    return this.http.get<ApiResponse<PtpResponse[]>>(`${this.B}/collections/loan-accounts/${loanAccountId}/ptp`);
  }
  updatePtpStatus(ptpId: number, status: PtpStatus): Observable<ApiResponse<PtpResponse>> {
    return this.http.patch<ApiResponse<PtpResponse>>(
      `${this.B}/collections/ptp/${ptpId}/status`, {},
      { params: new HttpParams().set('status', status) }
    );
  }

  // ── RISK ─────────────────────────────────────────────────────────
  getPortfolioMetrics(): Observable<ApiResponse<PortfolioMetrics>> {
    return this.http.get<ApiResponse<PortfolioMetrics>>(`${this.B}/risk/portfolio/metrics`);
  }

  // ── COMPLIANCE ───────────────────────────────────────────────────
  listAuditLogs(): Observable<ApiResponse<AuditLogResponse[]>> {
    return this.http.get<ApiResponse<AuditLogResponse[]>>(`${this.B}/compliance/audit-logs`);
  }
  listAuditByRef(refType: string, refId: number): Observable<ApiResponse<AuditLogResponse[]>> {
    return this.http.get<ApiResponse<AuditLogResponse[]>>(
      `${this.B}/compliance/audit-logs/ref`,
      { params: new HttpParams().set('refType', refType).set('refId', String(refId)) }
    );
  }
  listAuditByActor(userId: number): Observable<ApiResponse<AuditLogResponse[]>> {
    return this.http.get<ApiResponse<AuditLogResponse[]>>(
      `${this.B}/compliance/audit-logs/actor/${userId}`
    );
  }
}
