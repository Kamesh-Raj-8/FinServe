/**
 * SME Lend V2 — TypeScript Models
 * All interfaces match Spring Boot DTOs exactly.
 * Backend: http://localhost:8081  |  Auth: JWT Bearer
 */

// ── Enums ──────────────────────────────────────────────────────────
export type RoleName     = 'ADMIN'|'APPLICANT'|'AGENT'|'UNDERWRITER'|'OPERATIONS'|'SERVICING'|'COLLECTIONS'|'RISK'|'COMPLIANCE';
export type AppStatus    = 'DRAFT'|'KYC_PENDING'|'READY_TO_SUBMIT'|'SUBMITTED'|'ROUTED_TO_UW'|'UW_APPROVED'|'UW_REJECTED'|'OFFERED'|'OFFER_ACCEPTED'|'OFFER_REJECTED'|'DISBURSED';
export type KycStatus    = 'PENDING'|'VERIFIED'|'REJECTED';
export type OfferStatus  = 'OFFERED'|'ACCEPTED'|'REJECTED'|'EXPIRED';
export type UwDecision   = 'APPROVE'|'REJECT'|'RETURN';
export type DisburseMode = 'NEFT'|'IMPS'|'UPI';
export type RepayMode    = 'CASH'|'UPI'|'IMPS'|'NEFT'|'RTGS'|'OTHER';
export type BizType      = 'PROPRIETORSHIP'|'PARTNERSHIP'|'PVT_LTD'|'LLP'|'OTHER';
export type StatusFlag   = 'ACTIVE'|'INACTIVE';
export type PtpStatus    = 'OPEN'|'KEPT'|'BROKEN'|'CANCELLED';
export type InstStatus   = 'DUE'|'PAID'|'OVERDUE'|'PARTIAL';
export type DocType      = 'PAN'|'AADHAAR'|'GST'|'SHOP_LICENSE'|'BANK_STATEMENT'|'OTHER';

// ── API Wrapper ────────────────────────────────────────────────────
export interface ApiResponse<T> { success: boolean; message: string; data: T; }

// ── Auth ───────────────────────────────────────────────────────────
export interface AuthState { token: string|null; userId: number|null; email: string|null; role: RoleName|null; }
export interface LoginRequest    { email: string; password: string; }
export interface LoginResponse   { userId: number; email: string; role: RoleName; token: string; }
export interface RegisterRequest { fullName: string; email: string; password: string; phone?: string; role: 'APPLICANT'; bankAccountNo?: string; ifsc?: string; }
export interface RegisterResponse{ userId: number; email: string; role: RoleName; token: string; }

// ── SME ───────────────────────────────────────────────────────────
export interface CreateSmeRequest { legalName: string; tradeName?: string; businessType: BizType; industry: string; address: string; gstNo?: string; }
export interface UpdateSmeRequest { legalName: string; tradeName?: string; businessType: BizType; industry: string; address: string; gstNo?: string; }
export interface SmeResponse      { smeId: number; legalName: string; tradeName?: string; businessType: BizType; industry: string; address: string; gstNo?: string; status: StatusFlag; createdByUserId?: number; createdByEmail?: string; }

// ── Promoter ───────────────────────────────────────────────────────
export interface AddPromoterRequest { promoterName: string; mobile: string; ownershipPct: number; }
export interface PromoterResponse   { promoterId: number; smeId: number; promoterName: string; mobile: string; ownershipPct: number; kycStatus: KycStatus; createdByUserId?: number; createdByEmail?: string; }

// ── KYC ────────────────────────────────────────────────────────────
/** Refactored: sme_id, promoter_id, applicant_id as explicit FK fields */
export interface CreateKycRequest {
  smeId: number;
  promoterId?: number;   // optional FK to Promoter
  applicantId?: number;  // optional FK to AppUser (APPLICANT role)
}
export interface KycActionRequest { notes?: string; }
export interface KycResponse {
  kycId: number;
  smeId: number;
  smeLegalName?: string;
  promoterId?: number;
  promoterName?: string;
  applicantId?: number;
  applicantEmail?: string;
  applicantFullName?: string;
  verificationStatus: KycStatus;
  verifiedDate?: string;
  verifiedByUserId?: number;
  verifiedByEmail?: string;
  notes?: string;
}

// ── Applications ───────────────────────────────────────────────────
export interface CreateAppRequest { smeId: number; productId: number; requestedAmount: number; tenorMonths: number; purposeNote?: string; }
export interface AppResponse      { applicationId: number; smeId: number; smeLegalName?: string; productId: number; productName?: string; requestedAmount: number; tenorMonths: number; purposeNote?: string; status: AppStatus; createdByUserId?: number; createdByEmail?: string; createdDate?: string; }

// ── Documents ──────────────────────────────────────────────────────
export interface AddDocRequest { docType: DocType; fileUri: string; }
export interface DocResponse   {
  documentId: number;
  applicationId: number;
  docType: DocType;
  fileUri?: string;
  fileName?: string;
  contentType?: string;
  downloadUrl?: string;
  uploadedDate?: string;
}

// ── Loan Products ──────────────────────────────────────────────────
export interface LoanProductRequest  { productName: string; minAmount: number; maxAmount: number; minTenorMonths: number; maxTenorMonths: number; baseInterestRate: number; }
export interface LoanProductResponse { productId: number; productName: string; minAmount: number; maxAmount: number; minTenorMonths: number; maxTenorMonths: number; baseInterestRate: number; status: StatusFlag; }

// ── Underwriting ───────────────────────────────────────────────────
export interface UwDecisionRequest { decision: UwDecision; summaryNote?: string; }
export interface UwReviewResponse  { reviewId: number; applicationId: number; decision: UwDecision; summaryNote?: string; underwriterEmail?: string; newApplicationStatus: AppStatus; }

// ── Offers ─────────────────────────────────────────────────────────
export interface CreateOfferRequest { sanctionedAmount: number; interestRate: number; emiAmount: number; validUntil: string; }
export interface OfferResponse      { offerId: number; applicationId: number; sanctionedAmount: number; interestRate: number; emiAmount: number; validUntil?: string; offerStatus: OfferStatus; createdByEmail?: string; }

// ── Disbursement ───────────────────────────────────────────────────
export interface DisburseRequest     { mode: DisburseMode; transactionRef?: string; disbursementDate: string; }
export interface DisburseResponse    { disbursementId: number; applicationId: number; amount: number; mode: DisburseMode; transactionRef?: string; disbursementDate: string; status: string; loanAccount: LoanAccountResponse; }
export interface LoanAccountResponse { loanAccountId: number; accountNumber: string; principalSanctioned: number; interestRate: number; tenorMonths: number; startDate?: string; status: string; }

// ── Schedule ───────────────────────────────────────────────────────
export interface ScheduleResponse { scheduleId: number; loanAccountId: number; installmentNo: number; dueDate: string; principalDue: number; interestDue: number; totalDue: number; amountPaid: number; balanceDue: number; status: InstStatus; }

// ── Repayment ──────────────────────────────────────────────────────
export interface PostRepayRequest { loanAccountId: number; amount: number; mode: RepayMode; referenceNo?: string; paymentDate: string; }
export interface RepayResponse    { repaymentId: number; loanAccountId: number; amount: number; mode: RepayMode; referenceNo?: string; paymentDate: string; }

// ── Collections ────────────────────────────────────────────────────
export interface CreatePtpRequest { loanAccountId: number; promiseDate: string; promisedAmount: number; notes?: string; }
export interface PtpResponse      { ptpId: number; loanAccountId: number; promiseDate: string; promisedAmount: number; status: PtpStatus; notes?: string; }
export interface DelinqResponse   { delinquencyId: number; loanAccountId: number; dpd: number; bucket: string; asOfDate?: string; }

// ── Risk ───────────────────────────────────────────────────────────
export interface PortfolioMetrics { totalLoanAccounts: number; activeLoanAccounts: number; delinquentLoanAccounts: number; bucketCounts: Record<string, number>; }

// ── Compliance ─────────────────────────────────────────────────────
export interface AuditLogResponse { auditId: number; action: string; refType: string; refId: number; actorUserId: number; actorEmail?: string; message?: string; createdDate?: string; }

// ── Admin ──────────────────────────────────────────────────────────
export interface CreateUserRequest { fullName: string; email: string; password: string; phone?: string; role: RoleName; bankAccountNo?: string; ifsc?: string; }
export interface UserResponse      { userId: number; fullName: string; email: string; phone?: string; role: RoleName; status: StatusFlag; }
export interface RoleResponse      { roleId: number; roleName: RoleName; status?: StatusFlag; }
