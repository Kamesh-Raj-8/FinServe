import { Component, signal, computed, inject } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';
import { RoleName } from '../../core/models';

interface NavItem  { icon: string; label: string; route: string; roles: RoleName[]; }
interface NavGroup { label: string; items: NavItem[]; }

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, CommonModule],
  templateUrl: './shell.component.html'
})
export class ShellComponent {
  readonly auth = inject(AuthService);
  open = signal(false);
  init = computed(() => (this.auth.userEmail() ?? '?').charAt(0).toUpperCase());

  private NAV: NavGroup[] = [
    { label: 'Overview', items: [
      { icon: 'bi-speedometer2', label: 'Dashboard', route: '/dashboard', roles: [] },
    ]},
    { label: 'Origination', items: [
      { icon: 'bi-building',          label: 'SME Onboarding',  route: '/sme',          roles: ['ADMIN','APPLICANT','AGENT'] },
      { icon: 'bi-person-vcard',      label: 'KYC',            route: '/kyc',          roles: ['ADMIN','APPLICANT','AGENT'] },
      { icon: 'bi-file-earmark-text', label: 'Applications',   route: '/applications', roles: ['ADMIN','APPLICANT','AGENT'] },
    ]},
    { label: 'Credit & Ops', items: [
      { icon: 'bi-clipboard2-check',  label: 'Underwriting',   route: '/underwriting', roles: ['ADMIN','UNDERWRITER'] },
      // OPERATIONS: Offer + Disbursement only (no Servicing/Repayments)
      { icon: 'bi-send-check',        label: 'Operations',     route: '/operations',   roles: ['ADMIN','OPERATIONS'] },
      { icon: 'bi-tag',               label: 'Offers',         route: '/offers',       roles: ['ADMIN','OPERATIONS','APPLICANT','AGENT'] },
    ]},
    { label: 'Loan Management', items: [
      // SERVICING OFFICER: exclusive access to Servicing + Repayments
      { icon: 'bi-calendar3',   label: 'Servicing',   route: '/servicing',   roles: ['ADMIN','SERVICING'] },
      { icon: 'bi-cash-coin',   label: 'Repayments',  route: '/repayments',  roles: ['ADMIN','SERVICING'] },
    ]},
    { label: 'Risk & Oversight', items: [
      { icon: 'bi-graph-up-arrow',  label: 'Risk',        route: '/risk',        roles: ['ADMIN','RISK'] },
      { icon: 'bi-shield-check',    label: 'Compliance',  route: '/compliance',  roles: ['ADMIN','COMPLIANCE'] },
      { icon: 'bi-collection',      label: 'Collections', route: '/collections', roles: ['ADMIN','COLLECTIONS'] },
    ]},
    { label: 'Administration', items: [
      { icon: 'bi-gear', label: 'Admin Panel', route: '/admin', roles: ['ADMIN'] },
    ]},
  ];

  groups = computed(() => {
    const role = this.auth.userRole();
    return this.NAV
      .map(g => ({ ...g, items: g.items.filter(i => i.roles.length === 0 || (role && i.roles.includes(role))) }))
      .filter(g => g.items.length > 0);
  });

  toggle() { this.open.update(v => !v); }
  close()  { this.open.set(false); }
  logout() { this.auth.logout(); }
}
