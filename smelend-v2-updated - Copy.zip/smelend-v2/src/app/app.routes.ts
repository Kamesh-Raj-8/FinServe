import { Routes } from '@angular/router';
import { authGuard, roleGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  {
    path: 'auth',
    children: [
      { path: 'login',    loadComponent: () => import('./pages/auth/login/login.component').then(m => m.LoginComponent) },
      { path: 'register', loadComponent: () => import('./pages/auth/register/register.component').then(m => m.RegisterComponent) },
      { path: '', redirectTo: 'login', pathMatch: 'full' }
    ]
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./layout/shell/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      {
        path: 'dashboard',
        loadComponent: () => import('./pages/dashboard/dashboard.component').then(m => m.DashboardComponent)
      },
      // ── Origination ─────────────────────────────────────────────
      {
        path: 'sme',
        canActivate: [roleGuard('ADMIN','APPLICANT','AGENT')],
        children: [
          { path: '', loadComponent: () => import('./pages/sme/sme-list/sme-list.component').then(m => m.SmeListComponent) },
          { path: 'new', loadComponent: () => import('./pages/sme/sme-form/sme-form.component').then(m => m.SmeFormComponent) },
          { path: ':smeId', loadComponent: () => import('./pages/sme/sme-detail/sme-detail.component').then(m => m.SmeDetailComponent) },
        ]
      },
      {
        path: 'kyc',
        canActivate: [roleGuard('ADMIN','APPLICANT','AGENT')],
        loadComponent: () => import('./pages/kyc/kyc.component').then(m => m.KycComponent)
      },
      {
        path: 'applications',
        canActivate: [roleGuard('ADMIN','APPLICANT','AGENT')],
        children: [
          { path: '', loadComponent: () => import('./pages/applications/app-list/app-list.component').then(m => m.AppListComponent) },
          { path: 'new', loadComponent: () => import('./pages/applications/app-form/app-form.component').then(m => m.AppFormComponent) },
          { path: ':appId', loadComponent: () => import('./pages/applications/app-detail/app-detail.component').then(m => m.AppDetailComponent) },
        ]
      },
      // ── Credit & Ops ─────────────────────────────────────────────
      {
        path: 'underwriting',
        canActivate: [roleGuard('ADMIN','UNDERWRITER')],
        loadComponent: () => import('./pages/underwriting/underwriting.component').then(m => m.UnderwritingComponent)
      },
      {
        path: 'operations',
        canActivate: [roleGuard('ADMIN','OPERATIONS')],
        loadComponent: () => import('./pages/operations/operations.component').then(m => m.OperationsComponent)
      },
      {
        path: 'offers',
        canActivate: [roleGuard('ADMIN','OPERATIONS','APPLICANT','AGENT')],
        loadComponent: () => import('./pages/offers/offers.component').then(m => m.OffersComponent)
      },
      // ── Loan Management — SERVICING only ─────────────────────────
      {
        path: 'servicing',
        canActivate: [roleGuard('ADMIN','SERVICING')],
        loadComponent: () => import('./pages/servicing/servicing.component').then(m => m.ServicingComponent)
      },
      {
        path: 'repayments',
        canActivate: [roleGuard('ADMIN','SERVICING')],
        loadComponent: () => import('./pages/repayments/repayments.component').then(m => m.RepaymentsComponent)
      },
      // ── Risk & Oversight ─────────────────────────────────────────
      {
        path: 'risk',
        canActivate: [roleGuard('ADMIN','RISK')],
        loadComponent: () => import('./pages/risk/risk.component').then(m => m.RiskComponent)
      },
      {
        path: 'compliance',
        canActivate: [roleGuard('ADMIN','COMPLIANCE')],
        loadComponent: () => import('./pages/compliance/compliance.component').then(m => m.ComplianceComponent)
      },
      {
        path: 'collections',
        canActivate: [roleGuard('ADMIN','COLLECTIONS')],
        loadComponent: () => import('./pages/collections/collections.component').then(m => m.CollectionsComponent)
      },
      // ── Administration ────────────────────────────────────────────
      {
        path: 'admin',
        canActivate: [roleGuard('ADMIN')],
        loadComponent: () => import('./pages/admin/admin.component').then(m => m.AdminComponent)
      },
    ]
  },
  { path: '**', redirectTo: '/dashboard' }
];
